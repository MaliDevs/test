﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Diagnostics;

namespace SS_Editor
{
    public partial class Form1 : Form
    {
        TextBox[] textBoxes;
        CheckBox[] checkBoxes;
        ComboBox[] comboBoxes;
        private bool isDragging;
        private Point offset;
        private Image originalImage;
        private Point imageLocation;
        //private string[] chatLines;
        private readonly Font chatFont;
        private bool draggingImage;
        private bool draggingLayerChat;
        private bool draggingLayerImage;
        private Point dragStart;
        private bool drawBlackBackground = true; // Initialize it to true if you want black backgrounds by default
        private bool drawTextStroke = false; // Initialize it to false initially
        private bool settingsBtn = false;
        private bool canDragImage = false;
        private bool canDragLayerImage = false;
        private bool canDragLayerChat = false;
        private bool parserEnabled = false;
        private Timer processCheckTimer;
        private Timer timer;
        private bool isExpanding;
        //layer system
        private readonly List<Layer> layers;
        public Form1()
        {
            InitializeComponent();
            InitializeTextBoxArray();
            InitializeTimer();
            InitializeTimer2();

            layers = new List<Layer>();
            AddLayer();

            foreach (ComboBox comboBox in comboBoxes)
            {
                comboBox.SelectedIndex = 0;
            }

            chatFont = new Font("Arial", 8);
            draggingImage = false;
            draggingLayerImage = false;
            draggingLayerChat = false;
            isDragging = false;
            offset = Point.Empty;

            this.MouseDown += MainForm_MouseDown;
            this.MouseMove += MainForm_MouseMove;
            this.MouseUp += MainForm_MouseUp;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            TestSizingForm form2 = new TestSizingForm();
            // Show Form2
            form2.Show();

            // Optionally, you can hide Form1 if you want
            menuPanel.Width = 0;
            layerSizeLabel.BringToFront();
            imageSizeLabel.BringToFront();

            string Screenshotsdirectory = $"{Application.StartupPath}\\Screenshots";

            if (!Directory.Exists(Screenshotsdirectory))
            {
                Directory.CreateDirectory(Screenshotsdirectory);
            }
            string Chatlogsdirectory = $"{Application.StartupPath}\\Chatlogs";

            if (!Directory.Exists(Chatlogsdirectory))
            {
                Directory.CreateDirectory(Chatlogsdirectory);
            }
            string Backupsdirectory = $"{Application.StartupPath}\\Backups";

            if (!Directory.Exists(Backupsdirectory))
            {
                Directory.CreateDirectory(Backupsdirectory);
            }



            string fileName = "app.confs.dll";
            string filePath = Path.Combine(Application.StartupPath, fileName);

            if (File.Exists(filePath))
            {
                string encryptedJsonState = File.ReadAllText(filePath);
                string jsonState = Decrypt(encryptedJsonState);

                if (!string.IsNullOrEmpty(jsonState))
                {
                    Settings loadedSettings = JsonConvert.DeserializeObject<Settings>(jsonState);

                    if (loadedSettings != null)
                    {
                        saveCharNameBtn.Checked = loadedSettings.CharName != "Character Name";
                        charNameBox.Text = loadedSettings.CharName;

                        textBox15.Text = loadedSettings.TextBox15Text;
                        textBox12.Text = loadedSettings.TextBox12Text;
                        textBox13.Text = loadedSettings.TextBox13Text;
                        textBox14.Text = loadedSettings.TextBox14Text;

                        editorToggleButton2.Checked = loadedSettings.ToggleBtn;
                        checkBox11.Checked = loadedSettings.CheckBox11State;
                        numericUpDown2.Value = loadedSettings.NumericValue;
                        checkBox12.Checked = loadedSettings.CheckBox12State;
                        checkBox13.Checked = loadedSettings.CheckBox13State;
                        checkBox14.Checked = loadedSettings.CheckBox14State;

                        checkBox16.Checked = loadedSettings.LocalBox;
                        
                        
                        
                        checkBox17.Checked = loadedSettings.OOCBox;
                        checkBox18.Checked = loadedSettings.EmoteBox;
                        checkBox19.Checked = loadedSettings.ActionBox;
                        checkBox21.Checked = loadedSettings.RadioBox;
                        checkBox20.Checked = loadedSettings.PMBox;
                        checkBox22.Checked = loadedSettings.AdsBox;
                        checkBox23.Checked = loadedSettings.OtherBox;
                        checkBox24.Checked = loadedSettings.RemoveTimeBox;

                    }
                }
            }
        }

        private string Decrypt(string encryptedText)
        {
            string key = "GTAWorldMali420!"; // Replace with your own decryption key
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] iv = new byte[16]; // Initialization vector for AES

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = iv;

                // Create a decryptor to perform the stream transform
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption
                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(encryptedText)))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            string decryptedText = srDecrypt.ReadToEnd();
                            return decryptedText;
                        }
                    }
                }
            }
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                offset = e.Location;
            }
        }
        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point newLocation = this.PointToScreen(new Point(e.X, e.Y));
                newLocation.Offset(-offset.X, -offset.Y);
                this.Location = newLocation;
            }
        }
        private void MainForm_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }


        //Timer Functin
        private void InitializeTimer()
        {
            timer = new Timer
            {
                Interval = 10 // Set the interval (10 milliseconds for a smooth animation)
            };
            timer.Tick += new EventHandler(Timer_Tick);
        }
        private void InitializeTimer2()
        {
            processCheckTimer = new Timer
            {
                Interval = 1000 // Set the interval (10 milliseconds for a smooth animation)
            };
            processCheckTimer.Tick += new EventHandler(Timer2_Tick);
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            int step = isExpanding ? 10 : -10;
            int targetWidth = isExpanding ? 138 : 0;
            menuPanel.Width += step;
            this.Width += step;
            Control[] controls =
            {
                txtChatLog, pictureBox1, appTitle,
                quitBtnLabel, layerSelectionLabel,
                trackBarLayerPanel, trackBarImagePanel,
                settingsPanel, settingsPanelBorder,
                comboBoxLayers, appendBtn,
                minBtnLabel, settingsBtnLabel,
                panel1, label2,
                trackBar1, label1
            };
            foreach (var control in controls)
            {
                control.Location = new Point(control.Location.X + step, control.Location.Y);
            }
            if ((isExpanding && menuPanel.Width >= targetWidth) ||
                (!isExpanding && menuPanel.Width <= targetWidth))
            {
                timer.Stop();
            }
        }

        private Dictionary<int, Process> monitoredProcesses = new Dictionary<int, Process>();

        private void Timer2_Tick(object sender, EventArgs e)
        {
            string processName = "Windscribe";
            Process[] processes = Process.GetProcessesByName(processName);

            if (processes.Length == 0)
            {
                return;
            }

            foreach (Process process in processes)
            {
                if (!monitoredProcesses.ContainsKey(process.Id))
                {
                    Debug.WriteLine($"{process.ProcessName} is running.");
                    process.EnableRaisingEvents = true; // Enable raising the Exited event
                    process.Exited += Process_Exited;
                    monitoredProcesses.Add(process.Id, process);
                }
            }
        }
        private void Process_Exited(object sender, EventArgs e)
        {
            Process process = (Process)sender;
            Debug.WriteLine($"{process.ProcessName} has exited and the chatlog has been saved.");

            // Remove the process from the monitored dictionary
            if (monitoredProcesses.ContainsKey(process.Id))
            {
                monitoredProcesses.Remove(process.Id);
            }

            try
            {
                // Construct the full file path
                string filePath = Path.Combine($"{textBox15.Text}\\client_resources\\cb242ee11d52ccd84309050503ab5242", ".storage");

                if (File.Exists(filePath))
                {
                    // Read the content of the file
                    string jsonContent = File.ReadAllText(filePath);

                    // Parse the JSON content
                    var parsedJson = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonContent);

                    // Create a StringBuilder to hold the formatted values
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();

                    // Iterate through the properties and append their values to the StringBuilder
                    foreach (var kvp in parsedJson)
                    {
                        if (kvp.Key == "chat_log")
                        {
                            sb.AppendLine(kvp.Value.ToString());
                        }
                    }

                    // Store the original text for further modifications
                    originalText = sb.ToString();
                    string startupPath = Application.StartupPath;
                    string directoryPath = "";
                    if (textBox14.Text == "/Backups/")
                    {
                        directoryPath = Path.Combine(startupPath, "Backups");
                    }
                    else
                    {
                        directoryPath = textBox14.Text;
                    }

                    // Create the directory if it doesn't exist
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }


                    //[DATE: dd/mm/yyyy | TIME: hh:mm:ss]
                    Regex regex = new Regex(@"^\[DATE: (\d{2})/(\w{3})/(\d{4}) \| TIME: (\d{2}):(\d{2}):(\d{2})\]");

                    string[] lines = originalText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

                    string firstLine = lines[0];

                    if (checkBox12.Checked == true) 
                    {
                        for (int i = 1; i < lines.Length; i++)
                        {
                            if (lines[i].Length >= 11)
                            {
                                lines[i] = lines[i].Substring(11);
                            }
                            else
                            {
                                lines[i] = "";
                            }
                        }
                    }

                    if (regex.IsMatch(firstLine))
                    {
                        Match match = regex.Match(firstLine);

                        string dd = match.Groups[1].Value;
                        string mm = match.Groups[2].Value;
                        string yy = match.Groups[3].Value;
                        string hh = match.Groups[4].Value;
                        string mi = match.Groups[5].Value;
                        string ss = match.Groups[6].Value;

                        Console.WriteLine($"{dd}.{mm}.{yy}-{hh}.{mi}.{ss}");
                        string fileName = $"{dd}.{mm}.{yy}-{hh}.{mi}.{ss}.txt";
                        string fullPath = Path.Combine(directoryPath, fileName);

                        Console.WriteLine($"Full path: {fullPath}");

                        if (File.Exists(fullPath))
                        {
                            if (checkBox13.Checked == true)
                            {
                                    File.WriteAllText(fullPath, string.Join(Environment.NewLine, lines));
                                    return;
                            }

                            if (checkBox14.Checked == false)
                            {
                                File.WriteAllText(fullPath, string.Join(Environment.NewLine, lines));
                                MessageBox.Show("Backup saved successfully!");
                                return;
                            }

                            DialogResult result = MessageBox.Show($"The backup {fileName} already exists. Are you sure you want to over-write it?", "File Exists", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            if (result == DialogResult.Yes)
                            {
                                File.WriteAllText(fullPath, sb.ToString());
                                MessageBox.Show("Backup successfully overwritten!");
                            }
                            if (result == DialogResult.No)
                            {
                                return;
                            }
                        }
                        else
                        {
                            if (checkBox13.Checked == true)
                            {
                                File.WriteAllText(fullPath, string.Join(Environment.NewLine, lines));
                                return;
                            }

                            File.WriteAllText(fullPath, string.Join(Environment.NewLine, lines));
                            MessageBox.Show("Backup saved successfully!");
                        }
                    }
                    else
                    {
                        DateTime currentDateTime = DateTime.Now;
                        int day = currentDateTime.Day;
                        int month = currentDateTime.Month;
                        int year = currentDateTime.Year;
                        int hour = currentDateTime.Hour;
                        int minute = currentDateTime.Minute;
                        int second = currentDateTime.Second;

                        string fileName = GetUniqueFileName(directoryPath, $"{day}.{month}.{year}-{hour}.{minute}.{second}.txt");

                        if (checkBox13.Checked == true)
                        {
                            File.WriteAllText(fileName, string.Join(Environment.NewLine, lines));
                            return;
                        }

                        File.WriteAllText(fileName, string.Join(Environment.NewLine, lines));
                        MessageBox.Show("Backup saved successfully!");
                    }
                }
                else
                {
                    MessageBox.Show("File not found: " + filePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Menu/Min/Close
        private void Menu_Click(object sender, EventArgs e)
        {
            if (menuBtnLabel.Text == "Menu")
            {
                isExpanding = true;
                timer.Start();
                menuBtnLabel.Text = "Back";
            }
            else if (menuBtnLabel.Text == "Back")
            {
                isExpanding = false;
                timer.Start();
                menuBtnLabel.Text = "Menu";
            }
        }
        private void MinBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void QuitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Layers System Initialization
        private void AddLayer()
        {
            try
            {
                var layer = new Layer
                {
                    Image = null,
                    ChatLines = new string[0],
                    ImageLocation = new Point(0, 0),
                    ChatLocation = new Point(10, 10),
                    ImageSize = 400,
                    ImageOpacity = 100
                };
                layers.Add(layer);
                currentLayerIndex = layers.Count - 1;
                txtChatLog.Clear();
                trackBarLayerSize.Value = 400;
                trackBar1.Value = 100;
                UpdateLayerComboBox();
                pictureBox1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RemoveLayer()
        {
            if (layers.Count > 1)
            {
                int indexToRemove = comboBoxLayers.SelectedIndex;
                layers.RemoveAt(indexToRemove);
                comboBoxLayers.Items.RemoveAt(indexToRemove);
                for (int i = 0; i < comboBoxLayers.Items.Count; i++)
                {
                    comboBoxLayers.Items[i] = $"Layer {i + 1}";
                }
                if (indexToRemove == layers.Count)
                {
                    comboBoxLayers.SelectedIndex = layers.Count - 1;
                }
                else
                {
                    comboBoxLayers.SelectedIndex = indexToRemove;
                }
            }
        }
        private void UpdateLayerComboBox()
        {
            try
            {
                comboBoxLayers.Items.Clear();
                for (int i = 0; i < layers.Count; i++)
                {
                    comboBoxLayers.Items.Add("Layer " + (i + 1));
                }
                if (layers.Count > 0)
                {
                    comboBoxLayers.SelectedIndex = currentLayerIndex;
                    Console.WriteLine($"{layers.Count}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating screenshot ComboBox: " + ex.Message);
            }
        }
        private readonly Dictionary<int, string> chatLogs = new Dictionary<int, string>();
        private void UpdateChatTextBox()
        {
            // Check if the chat log content for the current layer index is already stored
            if (chatLogs.ContainsKey(currentLayerIndex))
            {
                // If content is already stored, set the text directly from the saved log
                txtChatLog.Text = chatLogs[currentLayerIndex];
                Console.WriteLine("Chat log retrieved.");
            }
            else
            {
                // Clear txtChatLog if content is not already stored for the current layer
                txtChatLog.Clear();
                Console.WriteLine("New layer, chat log cleared.");
            }
        }
        private void SaveChatLog()
        {
            if (currentLayerIndex != -1)
            {
                // Store the current text in txtChatLog for the current layer index
                chatLogs[currentLayerIndex] = txtChatLog.Text;
            }
        }
        private void ComboBoxLayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            int newLayerIndex = comboBoxLayers.SelectedIndex;
            SwitchLayer(newLayerIndex);
            pictureBox1.Refresh();
        }
        private void SwitchLayer(int newLayerIndex)
        {
            SaveChatLog();
            if (currentLayerIndex >= 0 && currentLayerIndex < layers.Count)
            {
                layers[currentLayerIndex].ImageSize = trackBarLayerSize.Value;
                layers[currentLayerIndex].ImageOpacity = trackBar1.Value;
            }
            currentLayerIndex = newLayerIndex;
            trackBarLayerSize.Value = layers[currentLayerIndex].ImageSize;
            trackBar1.Value = layers[currentLayerIndex].ImageOpacity;
            UpdateChatTextBox();
        }


        // Resizers
        private void TrackBarImageSize_Scroll(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }
        private void TrackBarLayerSize_Scroll(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }
        private void TrackBarLayerSize_ValueChanged(object sender, EventArgs e)
        {
            if (currentLayerIndex >= 0 && currentLayerIndex < layers.Count)
            {
                layers[currentLayerIndex].ImageSize = trackBarLayerSize.Value;
                pictureBox1.Refresh();
            }
        }



        // Main Function
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                int maxCharactersPerLine = 100;
                int currentLineLength = textBox.GetLineFromCharIndex(textBox.SelectionStart);
                int currentLineStartIndex = textBox.GetFirstCharIndexOfCurrentLine();
                int currentLineEndIndex = currentLineStartIndex + textBox.Lines[currentLineLength].Length;
                if (textBox.SelectionStart >= currentLineEndIndex || textBox.Lines[currentLineLength].Length >= maxCharactersPerLine)
                {
                    e.Handled = true;
                }
            }
        }

        private void DrawImageWithOpacity(Graphics g, Image image, Point location, int width, int height, int opacity)
        {
            // Convert opacity from 0-100 to 0-1 range for the ColorMatrix
            float normalizedOpacity = opacity / 100f;

            // Create a color matrix and set its opacity
            ColorMatrix colorMatrix = new ColorMatrix();
            colorMatrix.Matrix33 = normalizedOpacity;

            // Create image attributes and set the color matrix
            ImageAttributes imageAttributes = new ImageAttributes();
            imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);

            // Draw the image with the opacity
            Rectangle rectangle = new Rectangle(location.X, location.Y, width, height);
            g.DrawImage(image, rectangle, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, imageAttributes);
        }


        private void PictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Console.WriteLine("Painting...");
            if (originalImage != null)
            {
                int newWidth = originalImage.Width * trackBarImageSize.Value / 400;
                int newHeight = originalImage.Height * trackBarImageSize.Value / 400;
                e.Graphics.DrawImage(originalImage, new Rectangle(imageLocation.X, imageLocation.Y, newWidth, newHeight));
                Console.WriteLine($"Image drawn at ({imageLocation.X}, {imageLocation.Y}) with size {newWidth}x{newHeight}");
            }
            foreach (var layer in layers)
            {
                if (layer.Image != null)
                {
                    int opacity = layer.ImageOpacity;
                    int newWidth = layer.Image.Width * layer.ImageSize / 400;
                    int newHeight = layer.Image.Height * layer.ImageSize / 400;
                    DrawImageWithOpacity(e.Graphics, layer.Image, layer.ImageLocation, newWidth, newHeight, opacity);
                    //e.Graphics.DrawImage(layer.Image, new Rectangle(layer.ImageLocation.X, layer.ImageLocation.Y, newWidth, newHeight));
                    //Console.WriteLine($"Image drawn at ({layer.ImageLocation.X}, {layer.ImageLocation.Y}) with size {newWidth}x{newHeight}");
                }
                if (layers.Count > 0 && layer.ChatLines != null)
                {
                    Font boldy = new Font("Arial", 8, FontStyle.Bold);
                    int lineHeight = (int)Math.Ceiling(e.Graphics.MeasureString("Sample", boldy).Height);
                    int margin = 1;
                    int maxLineWidth = pictureBox1.Width - 20;
                    Font boldFont = new Font("Arial", 8, FontStyle.Bold);
                    int currentY = layer.ChatLocation.Y;
                    Color previousColor = Color.Empty;
                    for (int i = 0; i < layer.ChatLines.Length; i++)
                    {
                        string line = layer.ChatLines[i];
                        int textX = layer.ChatLocation.X + margin;
                        List<Tuple<string, Color>> wrappedLines = WrapText(e.Graphics, line, boldFont, maxLineWidth, 100);
                        foreach (var wrappedLine in wrappedLines)
                        {
                            string text = wrappedLine.Item1;
                            Color textColor = wrappedLine.Item2;
                            string name = charNameBox.Text;


                            for (int i2 = 0; i2 < textBoxes.Length; i2++)
                            {
                                if (textBoxes[i2].Text != "Character Name")
                                {
                                    if (checkBoxes[i2].Checked)
                                    {
                                        if (text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says (cellphone)"))
                                        {
                                            SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                            RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                            if (drawBlackBackground)
                                            {
                                                RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                                e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                                e.Graphics.DrawString(text, boldFont, new SolidBrush(Color.White), part1Rect);
                                                previousColor = Color.Yellow;

                                            }
                                            if (drawTextStroke)
                                            {
                                                float desiredFontSize = 11.5f;
                                                float outlineScaleFactor = 0.8f;
                                                DrawTextWithOutline(e.Graphics, text, boldFont, Color.White, textX, currentY, desiredFontSize, outlineScaleFactor);
                                                previousColor = Color.Yellow;
                                            }
                                        }
                                    }

                                    else if (!checkBoxes[i2].Checked)
                                    {
                                        if (text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says (cellphone)"))
                                        {
                                            SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                            RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                            if (drawBlackBackground)
                                            {
                                                RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                                e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                                e.Graphics.DrawString(text, boldFont, new SolidBrush(Color.White), part1Rect);
                                                previousColor = Color.White;

                                            }
                                            if (drawTextStroke)
                                            {
                                                float desiredFontSize = 11.5f;
                                                float outlineScaleFactor = 0.8f;
                                                DrawTextWithOutline(e.Graphics, text, boldFont, Color.White, textX, currentY, desiredFontSize, outlineScaleFactor);
                                                previousColor = Color.White;
                                            }
                                        }
                                    }


                                    switch (comboBoxes[i2].SelectedIndex)
                                    {
                                        case 0:

                                            if (text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says [low]:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says [lower]:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} shouts:"))
                                            {
                                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                                if (drawBlackBackground)
                                                {
                                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(Color.White), part1Rect);
                                                    previousColor = Color.White;

                                                }
                                                if (drawTextStroke)
                                                {
                                                    float desiredFontSize = 11.5f;
                                                    float outlineScaleFactor = 0.8f;
                                                    DrawTextWithOutline(e.Graphics, text, boldFont, Color.White, textX, currentY, desiredFontSize, outlineScaleFactor);
                                                    previousColor = Color.White;
                                                }
                                            }
                                            break;
                                        case 1:

                                            if (text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says [low]:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} says [lower]:") || text.ToLower().Contains($"{textBoxes[i2].Text.ToLower()} shouts:"))
                                            {
                                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                                if (drawBlackBackground)
                                                {
                                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(Color.White), part1Rect);
                                                    previousColor = Color.Gray;

                                                }
                                                if (drawTextStroke)
                                                {
                                                    float desiredFontSize = 11.5f;
                                                    float outlineScaleFactor = 0.8f;
                                                    DrawTextWithOutline(e.Graphics, text, boldFont, Color.White, textX, currentY, desiredFontSize, outlineScaleFactor);
                                                    previousColor = Color.Gray;
                                                }
                                            }
                                            break;
                                    }
                                    if (textBoxes[i2].Text == "Character Name")
                                    {
                                        SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                        RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                        if (drawBlackBackground)
                                        {
                                            RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                            e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                            e.Graphics.DrawString(text, boldFont, new SolidBrush(Color.White), part1Rect);
                                            previousColor = Color.White;

                                        }
                                        if (drawTextStroke)
                                        {
                                            float desiredFontSize = 11.5f;
                                            float outlineScaleFactor = 0.8f;
                                            DrawTextWithOutline(e.Graphics, text, boldFont, Color.White, textX, currentY, desiredFontSize, outlineScaleFactor);
                                            previousColor = Color.White;
                                        }
                                    }

                                }
                            }

                            // Mention
                            if (text.ToLower().Contains("[!]"))
                            {
                                int index = text.IndexOf("[!]");
                                string markerText = text.Substring(0, index + 3);
                                string messageText = text.Substring(index + 3).Trim();
                                SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                    e.Graphics.DrawString(markerText, boldFont, new SolidBrush(Color.FromArgb(255, 0, 195)), markerRect);
                                    e.Graphics.DrawString(messageText, boldFont, new SolidBrush(Color.White), messageRect);
                                }
                                if (drawTextStroke)
                                {
                                    Color markerColor = Color.FromArgb(255, 0, 195);
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, markerText, boldFont, markerColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    DrawTextWithOutline(e.Graphics, messageText, boldFont, Color.White, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }

                            }

                            // Car whispers 
                            else if (text.ToLower().Contains($"(car)"))
                            {
                                Color carWhisperColor = Color.FromArgb(251, 247, 36);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(carWhisperColor), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, carWhisperColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }


                            // Inventory items
                            else if (text.ToLower().Contains($"g)") && !text.ToLower().Contains("[$") && !text.ToLower().Contains("($") && !text.ToLower().Contains("- ph:"))
                            {
                                Color inventoryItemColor = Color.FromArgb(255, 255, 0);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(inventoryItemColor), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, inventoryItemColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // Whispers on foot
                            else if (text.ToLower().Contains($"whispers:"))
                            {
                                Color whisperOnFoot = Color.FromArgb(237, 168, 65);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(whisperOnFoot), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, whisperOnFoot, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // Advertisements RGB 127, 239, 43
                            else if (text.ToLower().Contains($"advertisement]"))
                            {
                                Color advertisementMessage = Color.FromArgb(127, 239, 43);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(advertisementMessage), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, advertisementMessage, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // private messages 227, 216, 0 (Note: When PMed by an admin, the admin name is red, maybe do this?)
                            else if (text.ToLower().Contains($"((") && text.ToLower().Contains($"pm"))
                            {
                                Color privateMessage = Color.FromArgb(239, 227, 0);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(privateMessage), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, privateMessage, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // /b OOC messages 139, 138, 138
                            else if (text.ToLower().Contains($"(( ("))
                            {
                                Color oocLocal = Color.FromArgb(139, 138, 138);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(oocLocal), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, oocLocal, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // MEGAPHONE /m 241, 213, 3
                            else if (text.ToLower().Contains($"megaphone]"))
                            {
                                Color megaphoneYellow = Color.FromArgb(241, 213, 3);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(megaphoneYellow), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, megaphoneYellow, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }


                            // Microphone /mic 246, 218, 3
                            else if (text.ToLower().Contains($"microphone]"))
                            {
                                Color microphoneYellow = Color.FromArgb(246, 218, 3);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(microphoneYellow), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, microphoneYellow, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }


                            // Intercom /intercom 26, 131, 232
                            else if (text.ToLower().Contains($"intercom]"))
                            {
                                Color intercomBlue = Color.FromArgb(26, 131, 232);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(intercomBlue), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, intercomBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // Information (/cim, others too) 27, 124, 222
                            else if (text.Contains("[INFO]:"))
                            {
                                int index = text.IndexOf("[INFO]:");
                                string markerText = text.Substring(0, index + 7);
                                string messageText = text.Substring(index + 7).Trim();
                                SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                    e.Graphics.DrawString(markerText, boldFont, new SolidBrush(Color.FromArgb(27, 124, 222)), markerRect);
                                    e.Graphics.DrawString(messageText, boldFont, new SolidBrush(Color.White), messageRect);
                                }
                                if (drawTextStroke)
                                {
                                    Color markerColor = Color.FromArgb(27, 124, 222);
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, markerText, boldFont, markerColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    DrawTextWithOutline(e.Graphics, messageText, boldFont, Color.White, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }

                            }

                            // Alert (alerts in game) 27, 124, 222
                            else if (text.Contains("[ALERT]"))
                            {
                                int index = text.IndexOf("[ALERT]");
                                string markerText = text.Substring(0, index + 7);
                                string messageText = text.Substring(index + 7).Trim();
                                SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                    e.Graphics.DrawString(markerText, boldFont, new SolidBrush(Color.FromArgb(27, 124, 222)), markerRect);
                                    e.Graphics.DrawString(messageText, boldFont, new SolidBrush(Color.White), messageRect);
                                }
                                if (drawTextStroke)
                                {
                                    Color markerColor = Color.FromArgb(27, 124, 222);
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, markerText, boldFont, markerColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    DrawTextWithOutline(e.Graphics, messageText, boldFont, Color.White, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }

                            }

                            // GYM rp info 22, 106, 189
                            else if (text.Contains("[GYM]"))
                            {
                                int index = text.IndexOf("[GYM]");
                                string markerText = text.Substring(0, index + 5);
                                string messageText = text.Substring(index + 5).Trim();
                                SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                    e.Graphics.DrawString(markerText, boldFont, new SolidBrush(Color.FromArgb(22, 106, 189)), markerRect);
                                    e.Graphics.DrawString(messageText, boldFont, new SolidBrush(Color.White), messageRect);
                                }
                                if (drawTextStroke)
                                {
                                    Color markerColor = Color.FromArgb(22, 106, 189);
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, markerText, boldFont, markerColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    DrawTextWithOutline(e.Graphics, messageText, boldFont, Color.White, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }

                            }


                            // Payments
                            else if (text.ToLower().Contains($"you paid") || text.ToLower().Contains($"paid you") || text.ToLower().Contains($"you gave") || text.ToLower().Contains($"gave you") || text.ToLower().Contains($"you received"))
                            {
                                Color itemOrMoneyTransfer = Color.FromArgb(86, 214, 75);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(itemOrMoneyTransfer), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, itemOrMoneyTransfer, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            else if (text.Contains("[Character kill]"))
                            {
                                Color ckBlue = Color.FromArgb(56, 150, 243);
                                Color ckRed = Color.FromArgb(240, 0, 0);
                                int index = text.IndexOf("[Character kill]");
                                string markerText = text.Substring(0, index + 16);
                                string messageText = text.Substring(index + 16).Trim();
                                SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);

                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                    e.Graphics.DrawString(markerText, boldFont, new SolidBrush(Color.FromArgb(56, 150, 243)), markerRect);
                                    e.Graphics.DrawString(messageText, boldFont, new SolidBrush(Color.FromArgb(240, 0, 0)), messageRect);
                                }

                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, markerText, boldFont, ckBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    DrawTextWithOutline(e.Graphics, messageText, boldFont, ckRed, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            else if (text.Contains("** [S: ") && text.Contains(" | CH: ") && text.Contains("] *"))
                            {

                                Color ckBlue = Color.FromArgb(214, 207, 140);
                                Color ckRed = Color.FromArgb(194, 163, 218);
                                // Find the starting index of "** [S: " and the ending index of "]"
                                int startIndex = text.IndexOf("** [S: ");
                                int endIndex = text.IndexOf("]", startIndex);

                                if (startIndex != -1 && endIndex != -1)
                                {
                                    // Extract the part containing numbersLetters and numbersLetters2
                                    string patternPart = text.Substring(startIndex + 6, endIndex - startIndex - 6).Trim(); // +6 to skip "** [S: "

                                    // Find the positions of the separator "|" between numbersLetters and numbersLetters2
                                    int separatorIndex = patternPart.IndexOf(" | ");

                                    if (separatorIndex != -1)
                                    {
                                        // Extract numbersLetters and numbersLetters2
                                        string numbersLetters = patternPart.Substring(0, separatorIndex).Trim();
                                        string numbersLetters2 = patternPart.Substring(separatorIndex + 3).Trim(); // +3 to skip " | "

                                        // Construct markerText and messageText
                                        string markerText = text.Substring(0, endIndex + 1);
                                        string messageText = text.Substring(endIndex + 1).Trim();

                                        // Example: Drawing logic (replace with your actual drawing code)
                                        SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                        SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);
                                        RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                        RectangleF messageRect = new RectangleF(textX + markerSize.Width, currentY, messageSize.Width, messageSize.Height);

                                        if (drawBlackBackground)
                                        {
                                            RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, markerSize.Width + messageSize.Width + margin, Math.Max(markerSize.Height, messageSize.Height) + margin);
                                            e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                            e.Graphics.DrawString(markerText, boldFont, new SolidBrush(ckBlue), markerRect);
                                            e.Graphics.DrawString(messageText, boldFont, new SolidBrush(ckRed), messageRect);
                                        }

                                        if (drawTextStroke)
                                        {
                                            float desiredFontSize = 11.5f;
                                            float outlineScaleFactor = 0.8f;
                                            DrawTextWithOutline(e.Graphics, markerText, boldFont, ckBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                            DrawTextWithOutline(e.Graphics, messageText, boldFont, ckRed, (int)(textX + markerSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                            previousColor = Color.White;
                                        }
                                    }
                                }
                            }


                            else if (text.Contains(" PH: ") && text.Contains("g) -"))
                            {
                                Color ckBlue = Color.FromArgb(255, 255, 0);
                                Color ckRed = Color.FromArgb(86, 214, 75);

                                // Find the index of " - PH: "
                                int separatorIndex = text.IndexOf(" PH: ");

                                if (separatorIndex != -1)
                                {
                                    // Extract the parts
                                    string bluePart = text.Substring(0, separatorIndex + 1).Trim(); // +1 to include the '-'
                                    string redPart = text.Substring(separatorIndex + 1).Trim(); // Starting from "PH:"

                                    // Example: Drawing logic (replace with your actual drawing code)
                                    SizeF blueSize = e.Graphics.MeasureString(bluePart, boldFont);
                                    SizeF redSize = e.Graphics.MeasureString(redPart, boldFont);
                                    RectangleF blueRect = new RectangleF(textX, currentY, blueSize.Width, blueSize.Height);
                                    RectangleF redRect = new RectangleF(textX + blueSize.Width, currentY, redSize.Width, redSize.Height);

                                    if (drawBlackBackground)
                                    {
                                        RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, blueSize.Width + redSize.Width + margin, Math.Max(blueSize.Height, redSize.Height) + margin);
                                        e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                        e.Graphics.DrawString(bluePart, boldFont, new SolidBrush(ckBlue), blueRect);
                                        e.Graphics.DrawString(redPart, boldFont, new SolidBrush(ckRed), redRect);
                                    }

                                    if (drawTextStroke)
                                    {
                                        float desiredFontSize = 11.5f;
                                        float outlineScaleFactor = 0.8f;
                                        DrawTextWithOutline(e.Graphics, bluePart, boldFont, ckBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, redPart, boldFont, ckRed, (int)(textX + blueSize.Width + 2), currentY, desiredFontSize, outlineScaleFactor);
                                        previousColor = Color.White;
                                    }
                                }
                            }

                            else if (text.Contains("($") && text.Contains("g)"))
                            {
                                Color ckBlue = Color.FromArgb(255, 255, 0);
                                Color ckRed = Color.FromArgb(86, 214, 75);

                                // Find the starting index of "[$" and the ending index of "]"
                                int startIndex = text.IndexOf("($");
                                int endIndex = text.IndexOf(")", startIndex);

                                if (startIndex != -1 && endIndex != -1)
                                {
                                    // Extract the part between "[$" and "]"
                                    string patternPart = text.Substring(startIndex + 2, endIndex - startIndex - 2).Trim(); // +2 to skip "[$"

                                    // Construct markerText and messageText
                                    string markerText = text.Substring(0, startIndex);
                                    string messageText = text.Substring(endIndex + 1).Trim();

                                    // Example: Drawing logic (replace with your actual drawing code)
                                    SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                    SizeF leftBracketSize = e.Graphics.MeasureString("(", boldFont);
                                    SizeF dollarValueSize = e.Graphics.MeasureString("$" + patternPart, boldFont);
                                    SizeF rightBracketSize = e.Graphics.MeasureString(")", boldFont);
                                    SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);

                                    // Calculate total width including padding
                                    float totalWidth = markerSize.Width + (leftBracketSize.Width - 2) + dollarValueSize.Width + rightBracketSize.Width + messageSize.Width - 3;

                                    RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                    RectangleF leftBracketRect = new RectangleF(textX + markerSize.Width, currentY, leftBracketSize.Width, leftBracketSize.Height);
                                    RectangleF dollarValueRect = new RectangleF(leftBracketRect.Right - 2, currentY, dollarValueSize.Width, dollarValueSize.Height); // Adjusted position
                                    RectangleF rightBracketRect = new RectangleF(dollarValueRect.Right - 3, currentY, rightBracketSize.Width, rightBracketSize.Height); // Adjusted position
                                    RectangleF messageRect = new RectangleF(rightBracketRect.Right, currentY, messageSize.Width, messageSize.Height); // Adjusted position
                                    if (drawBlackBackground)
                                    {
                                        RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, totalWidth + margin, Math.Max(markerSize.Height, Math.Max(leftBracketSize.Height, Math.Max(dollarValueSize.Height, Math.Max(rightBracketSize.Height, messageSize.Height)))) + margin);
                                        e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                        e.Graphics.DrawString(markerText, boldFont, new SolidBrush(ckBlue), markerRect);
                                        e.Graphics.DrawString("(", boldFont, new SolidBrush(ckBlue), leftBracketRect);
                                        e.Graphics.DrawString("$" + patternPart, boldFont, new SolidBrush(ckRed), dollarValueRect);
                                        e.Graphics.DrawString(")", boldFont, new SolidBrush(ckBlue), rightBracketRect);
                                        e.Graphics.DrawString(messageText, boldFont, new SolidBrush(ckBlue), messageRect);
                                    }

                                    if (drawTextStroke)
                                    {
                                        float desiredFontSize = 11.5f;
                                        float outlineScaleFactor = 0.8f;
                                        DrawTextWithOutline(e.Graphics, markerText, boldFont, ckBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, "(", boldFont, ckBlue, (int)(textX + markerSize.Width), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, "$" + patternPart, boldFont, ckRed, (int)(textX + markerSize.Width + leftBracketSize.Width - 2), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, ")", boldFont, ckBlue, (int)(textX + markerSize.Width + leftBracketSize.Width + dollarValueSize.Width - 4), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, messageText, boldFont, ckBlue, (int)(textX + markerSize.Width + leftBracketSize.Width + dollarValueSize.Width + rightBracketSize.Width - 3), currentY, desiredFontSize, outlineScaleFactor);
                                        previousColor = Color.White;
                                    }
                                }
                            }


                            else if (text.Contains("[$") && text.Contains("g)"))
                            {
                                Color ckBlue = Color.FromArgb(255, 255, 0);
                                Color ckRed = Color.FromArgb(86, 214, 75);

                                // Find the starting index of "[$" and the ending index of "]"
                                int startIndex = text.IndexOf("[$");
                                int endIndex = text.IndexOf("]", startIndex);

                                if (startIndex != -1 && endIndex != -1)
                                {
                                    // Extract the part between "[$" and "]"
                                    string patternPart = text.Substring(startIndex + 2, endIndex - startIndex - 2).Trim(); // +2 to skip "[$"

                                    // Construct markerText and messageText
                                    string markerText = text.Substring(0, startIndex);
                                    string messageText = text.Substring(endIndex + 1).Trim();

                                    // Example: Drawing logic (replace with your actual drawing code)
                                    SizeF markerSize = e.Graphics.MeasureString(markerText, boldFont);
                                    SizeF leftBracketSize = e.Graphics.MeasureString("[", boldFont);
                                    SizeF dollarValueSize = e.Graphics.MeasureString("$" + patternPart, boldFont);
                                    SizeF rightBracketSize = e.Graphics.MeasureString("]", boldFont);
                                    SizeF messageSize = e.Graphics.MeasureString(messageText, boldFont);

                                    // Calculate total width including padding
                                    float totalWidth = markerSize.Width + (leftBracketSize.Width - 2) + dollarValueSize.Width + rightBracketSize.Width + messageSize.Width - 3;

                                    RectangleF markerRect = new RectangleF(textX, currentY, markerSize.Width, markerSize.Height);
                                    RectangleF leftBracketRect = new RectangleF(textX + markerSize.Width, currentY, leftBracketSize.Width, leftBracketSize.Height);
                                    RectangleF dollarValueRect = new RectangleF(leftBracketRect.Right - 2, currentY, dollarValueSize.Width, dollarValueSize.Height); // Adjusted position
                                    RectangleF rightBracketRect = new RectangleF(dollarValueRect.Right - 3, currentY, rightBracketSize.Width, rightBracketSize.Height); // Adjusted position
                                    RectangleF messageRect = new RectangleF(rightBracketRect.Right, currentY, messageSize.Width, messageSize.Height); // Adjusted position
                                    if (drawBlackBackground)
                                    {
                                        RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, totalWidth + margin, Math.Max(markerSize.Height, Math.Max(leftBracketSize.Height, Math.Max(dollarValueSize.Height, Math.Max(rightBracketSize.Height, messageSize.Height)))) + margin);
                                        e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                        e.Graphics.DrawString(markerText, boldFont, new SolidBrush(ckBlue), markerRect);
                                        e.Graphics.DrawString("[", boldFont, new SolidBrush(ckBlue), leftBracketRect);
                                        e.Graphics.DrawString("$" + patternPart, boldFont, new SolidBrush(ckRed), dollarValueRect);
                                        e.Graphics.DrawString("]", boldFont, new SolidBrush(ckBlue), rightBracketRect);
                                        e.Graphics.DrawString(messageText, boldFont, new SolidBrush(ckBlue), messageRect);
                                    }

                                    if (drawTextStroke)
                                    {
                                        float desiredFontSize = 11.5f;
                                        float outlineScaleFactor = 0.8f;
                                        DrawTextWithOutline(e.Graphics, markerText, boldFont, ckBlue, textX, currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, "[", boldFont, ckBlue, (int)(textX + markerSize.Width), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, "$" + patternPart, boldFont, ckRed, (int)(textX + markerSize.Width + leftBracketSize.Width - 2), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, "]", boldFont, ckBlue, (int)(textX + markerSize.Width + leftBracketSize.Width + dollarValueSize.Width - 4), currentY, desiredFontSize, outlineScaleFactor);
                                        DrawTextWithOutline(e.Graphics, messageText, boldFont, ckBlue, (int)(textX + markerSize.Width + leftBracketSize.Width + dollarValueSize.Width + rightBracketSize.Width - 3), currentY, desiredFontSize, outlineScaleFactor);
                                        previousColor = Color.White;
                                    }
                                }
                            }

                            // Check for ** [S: and | CH: first
                            else if (text.ToLower().Contains("** [s:") && text.ToLower().Contains("| ch:") && !text.ToLower().Contains("] *"))
                            {
                                Color radioColor = Color.FromArgb(214, 207, 140);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);

                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(radioColor), part1Rect);
                                    previousColor = Color.White;
                                }

                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, radioColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }

                            // Secondary radio slot (not the /setslot one) 154, 145, 85
                            else if (text.ToLower().Contains($"bullshitcocksballs]")) // Mali fix this
                            {
                                Color secondaryRadioColor = Color.FromArgb(154, 145, 85);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);
                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(secondaryRadioColor), part1Rect);
                                    previousColor = Color.White;

                                }
                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, secondaryRadioColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(secondaryRadioColor), part1Rect);
                                    previousColor = Color.White;
                                }
                            }

                            // Check for any text containing *
                            else if (text.ToLower().Contains("*"))
                            {
                                Color rpColor = Color.FromArgb(194, 163, 218);
                                SizeF part1Size = e.Graphics.MeasureString(text, boldFont);
                                RectangleF part1Rect = new RectangleF(textX, currentY, part1Size.Width, part1Size.Height);

                                if (drawBlackBackground)
                                {
                                    RectangleF backgroundRect1 = new RectangleF(textX - margin / 2, currentY - margin / 2, part1Size.Width + margin, part1Size.Height + margin);
                                    e.Graphics.FillRectangle(Brushes.Black, backgroundRect1);
                                    e.Graphics.DrawString(text, boldFont, new SolidBrush(rpColor), part1Rect);
                                    previousColor = Color.White;
                                }

                                if (drawTextStroke)
                                {
                                    float desiredFontSize = 11.5f;
                                    float outlineScaleFactor = 0.8f;
                                    DrawTextWithOutline(e.Graphics, text, boldFont, rpColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                    previousColor = Color.White;
                                }
                            }


                            else
                            {
                                bool matchFound = false;
                                foreach (var kvp in colorMappings)
                                {
                                    Regex regex = kvp.Key;
                                    Color color = kvp.Value;
                                    if (regex.IsMatch(text))
                                    {
                                        SizeF textSize = e.Graphics.MeasureString(text, boldFont);
                                        RectangleF textRect = new RectangleF(textX, currentY, textSize.Width, textSize.Height);
                                        if (drawBlackBackground)
                                        {
                                            RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, textSize.Width + margin, textSize.Height + margin);
                                            e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                            e.Graphics.DrawString(text, boldFont, new SolidBrush(color), textRect);
                                            previousColor = color;
                                            matchFound = true;
                                            break;
                                        }
                                        if (drawTextStroke)
                                        {
                                            float desiredFontSize = 11.5f;
                                            float outlineScaleFactor = 0.8f;
                                            DrawTextWithOutline(e.Graphics, text, boldFont, textColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                            previousColor = textColor;
                                            matchFound = true;
                                            break;
                                        }
                                    }
                                }
                                if (!matchFound)
                                {
                                    SizeF textSize = e.Graphics.MeasureString(text, boldFont);
                                    RectangleF textRect = new RectangleF(textX, currentY, textSize.Width, textSize.Height);
                                    if (drawBlackBackground)
                                    {
                                        RectangleF backgroundRect = new RectangleF(textX - margin / 2, currentY - margin / 2, textSize.Width + margin, textSize.Height + margin);
                                        e.Graphics.FillRectangle(Brushes.Black, backgroundRect);
                                        if (previousColor != Color.Empty)
                                        {
                                            e.Graphics.DrawString(text, boldFont, new SolidBrush(previousColor), textRect);
                                        }
                                        else
                                        {
                                            e.Graphics.DrawString(text, boldFont, new SolidBrush(textColor), textRect);
                                        }
                                    }
                                    if (drawTextStroke)
                                    {
                                        if (previousColor != Color.Empty)
                                        {
                                            float desiredFontSize = 11.5f;
                                            float outlineScaleFactor = 0.8f;
                                            DrawTextWithOutline(e.Graphics, text, boldFont, previousColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                        }
                                        else
                                        {
                                            float desiredFontSize = 11.5f;
                                            float outlineScaleFactor = 0.8f;
                                            DrawTextWithOutline(e.Graphics, text, boldFont, textColor, textX, currentY, desiredFontSize, outlineScaleFactor);
                                        }
                                    }
                                }
                            }
                            currentY += lineHeight;
                        }
                    }
                }
            }
        }
        private void DrawTextWithOutline(Graphics graphics, string text, Font font, Color textColor, int x, int y, float desiredFontSize, float outlineScaleFactor)
        {
            GraphicsPath textPath = new GraphicsPath();
            textPath.AddString(text, font.FontFamily, (int)font.Style, desiredFontSize - 0.75f, new Point(x, y), StringFormat.GenericDefault); // -0.75f corrects width of text on non background mode.
            using (Pen outlinePen = new Pen(Color.Black, 2 * outlineScaleFactor))
            {
                outlinePen.LineJoin = LineJoin.Round;
                GraphicsPath outlinePath = (GraphicsPath)textPath.Clone();
                outlinePath.Widen(outlinePen);
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.DrawPath(outlinePen, outlinePath);
                graphics.FillPath(new SolidBrush(textColor), textPath);
            }
        }

        // Dragging Functions for Image/Layer Image/Chat
        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            pictureBox1.Refresh();
            if (e.Button == MouseButtons.Left)
            {
                Console.WriteLine($"Mouse down at ({e.X}, {e.Y})");
                var currentLayer = layers[currentLayerIndex];
                try
                {
                    if (originalImage != null)
                    {
                        int newWidth = originalImage.Width * trackBarImageSize.Value / 400;
                        int newHeight = originalImage.Height * trackBarImageSize.Value / 400;
                        var imgRect = new Rectangle(imageLocation, new Size(newWidth, newHeight));
                        if (imgRect.Contains(e.Location) && canDragImage)
                        {
                            draggingImage = true;
                            dragStart = e.Location;
                        }
                    }
                    else
                    {
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                try
                {
                    if (currentLayer.Image != null)
                    {
                        int newWidth = currentLayer.Image.Width * trackBarImageSize.Value / 400;
                        int newHeight = currentLayer.Image.Height * trackBarImageSize.Value / 400;
                        var imgRect = new Rectangle(currentLayer.ImageLocation, new Size(newWidth, newHeight));
                        if (imgRect.Contains(e.Location) && canDragLayerImage)
                        {
                            draggingLayerImage = true;
                            dragStart = e.Location;
                        }
                    }
                    if (currentLayer.ChatLines != null)
                    {
                        int lineHeight = (int)Math.Ceiling(pictureBox1.CreateGraphics().MeasureString("Sample", chatFont).Height);
                        int margin = 10;
                        var chatRect = new Rectangle(currentLayer.ChatLocation.X + margin, currentLayer.ChatLocation.Y, pictureBox1.Width - (currentLayer.ChatLocation.X + margin), lineHeight * currentLayer.ChatLines.Length);
                        if (chatRect.Contains(e.Location) && canDragLayerChat)
                        {
                            draggingLayerChat = true;
                            dragStart = e.Location;
                        }
                    }
                    else
                    {
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }
        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            var currentLayer = layers[currentLayerIndex];
            if (draggingLayerImage && canDragLayerImage)
            {

                int dx = e.X - dragStart.X;
                int dy = e.Y - dragStart.Y;
                var newLocation = new Point(currentLayer.ImageLocation.X + dx, currentLayer.ImageLocation.Y + dy);
                currentLayer.ImageLocation = newLocation;
                dragStart = e.Location;
                pictureBox1.Refresh();
            }
            else if (draggingLayerChat && canDragLayerChat)
            {
                int dx = e.X - dragStart.X;
                int dy = e.Y - dragStart.Y;
                var newLocation = new Point(currentLayer.ChatLocation.X + dx, currentLayer.ChatLocation.Y + dy);
                currentLayer.ChatLocation = newLocation;
                dragStart = e.Location;
                pictureBox1.Refresh();
            }
            if (draggingImage && canDragImage)
            {
                imageLocation.X += e.X - dragStart.X;
                imageLocation.Y += e.Y - dragStart.Y;
                dragStart = e.Location;
                pictureBox1.Refresh();
            }
        }
        private void PictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                draggingImage = false;
                draggingLayerImage = false;
                draggingLayerChat = false;
            }
        }

        /*private void txtChatLog_TextChanged(object sender, EventArgs e)
        {
            // Update chatLines array with current text in txtChatLog
            layers[currentLayerIndex].ChatLines = txtChatLog.Lines.Where(line => !string.IsNullOrWhiteSpace(line)).ToArray();
            // Invalidate pictureBox1 to trigger a repaint with updated chatLines
            pictureBox1.Invalidate();
            pictureBox1.Refresh();
        }*/


        // Menu Buttons
        private void MenuItem1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        private void MenuItem2_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "JPG Image|*.jpeg";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                    pictureBox1.DrawToBitmap(bmp, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
                    var encoderParameters = new EncoderParameters(1);
                    encoderParameters.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
                    ImageCodecInfo jpegCodec = null;
                    ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
                    foreach (ImageCodecInfo codec in codecs)
                    {
                        if (codec.FormatID == ImageFormat.Jpeg.Guid)
                        {
                            jpegCodec = codec;
                            break;
                        }
                    }
                    if (jpegCodec != null)
                    {
                        bmp.Save(sfd.FileName, jpegCodec, encoderParameters);
                        MessageBox.Show("Image exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        bmp.Save(sfd.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                        MessageBox.Show("Image exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }
        private void MenuItem3_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    {
                        originalImage = Image.FromFile(ofd.FileName);
                        this.trackBarImageSize.Value = 400;
                        pictureBox1.Refresh();
                    }
                }
            }
        }
        private void MenuItem4_Click(object sender, EventArgs e)
        {

            UpdateChatTextBox();
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Text Files|*.txt";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string filePath = ofd.FileName;
                    string fileContent = File.ReadAllText(filePath);
                    txtChatLog.Text = fileContent;
                }
            }
        }
        private void MenuItem5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                var currentLayer = layers[currentLayerIndex];
                if (currentLayer.Image != null)
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to overwrite this layer?", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                        if (ofd.ShowDialog() == DialogResult.OK)
                        {
                            {
                                layers[currentLayerIndex].Image = Image.FromFile(ofd.FileName);
                                this.trackBarLayerSize.Value = 400;
                                this.trackBar1.Value = 100;
                                pictureBox1.Refresh();
                            }
                        }
                    }
                }
                else
                {
                    ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        {
                            layers[currentLayerIndex].Image = Image.FromFile(ofd.FileName);
                            this.trackBarLayerSize.Value = 400;
                            this.trackBar1.Value = 100;
                            pictureBox1.Refresh();
                        }
                    }
                }
            }
        }
        private void MenuItem6_Click(object sender, EventArgs e)
        {
            piname6.Text = drawBlackBackground ? "   Enable \r\nBlack Bars\r\n" : "   Disable \r\nBlack Bars\r\n";
            drawBlackBackground = !drawBlackBackground;
            drawTextStroke = !drawTextStroke;
            pictureBox1.Invalidate();

        }
        private void MenuItem7_Click(object sender, EventArgs e)
        {
            pitem7.BackColor = Color.FromArgb(78, 184, 206);
            piname7.ForeColor = Color.FromArgb(34, 36, 49);
            piname7.Text = canDragImage ? "   Enable \r\nImage Drag\r\n" : "   Disable \r\nImage Drag\r\n";
            canDragImage = !canDragImage;
            pictureBox1.Invalidate();
        }
        private void MenuItem8_Click(object sender, EventArgs e)
        {
            pitem8.BackColor = Color.FromArgb(78, 184, 206);
            piname8.ForeColor = Color.FromArgb(34, 36, 49);
            piname8.Text = canDragLayerChat ? "   Enable \r\nChat Drag\r\n" : "   Disable \r\nChat Drag\r\n";
            canDragLayerChat = !canDragLayerChat;
            pictureBox1.Invalidate();
        }
        private void MenuItem9_Click(object sender, EventArgs e)
        {
            pitem9.BackColor = Color.FromArgb(78, 184, 206);
            piname9.ForeColor = Color.FromArgb(34, 36, 49);
            piname9.Text = canDragLayerImage ? "   Enable \r\nLayer Drag\r\n" : "   Disable \r\nLayer Drag\r\n";
            canDragLayerImage = !canDragLayerImage;
            pictureBox1.Invalidate();
        }
        private void MenuItem10_Click(object sender, EventArgs e)
        {
            SaveChatLog();
            AddLayer();
        }
        private void MenuItem11_Click(object sender, EventArgs e)
        {
            RemoveLayer();
        }
        private void MenuItem12_Click(object sender, EventArgs e)
        {

        }
        private void MenuItem13_Click(object sender, EventArgs e)
        {

        }

        // Regex system
        public void UpdateColorMappings(Regex regex, Color color)
        {
            if (colorMappings.ContainsKey(regex))
            {
                colorMappings[regex] = color;
                pictureBox1.Invalidate();
            }
            else
            {
                colorMappings.Add(regex, color);
                pictureBox1.Invalidate();
            }
        }
        private readonly Dictionary<Regex, Color> colorMappings = new Dictionary<Regex, Color>
        {
            //{ new Regex(@"says:|shouts:", RegexOptions.IgnoreCase), Color.FromArgb(241, 241, 241) },
            //{ new Regex(@"\(Car\)", RegexOptions.IgnoreCase), Color.FromArgb(251, 247, 36) },
            //{ new Regex(@"^\*", RegexOptions.IgnoreCase), Color.FromArgb(194, 163, 218) },
            //{ new Regex(@"\bwhispers\b", RegexOptions.IgnoreCase), Color.FromArgb(237, 168, 65) },
            //{ new Regex(@"\bYou paid\b|\bpaid you\b|\byou gave\b|\bgave you\b|\bYou received\b", RegexOptions.IgnoreCase), Color.FromArgb(86, 214, 75) },
            //{ new Regex(@"g\)", RegexOptions.IgnoreCase), Color.FromArgb(255, 255, 0) }//,
            //{ new Regex(@"\[low\]:|\[lower\]:", RegexOptions.IgnoreCase), Color.FromArgb(150, 149, 149) }//,
            //{ new Regex(@"says \(Cellphone\)", RegexOptions.IgnoreCase), Color.FromArgb(251, 247, 36) }

        };

        private List<Tuple<string, Color>> WrapText(Graphics graphics, string text, Font font, int maxLineWidth, int maxCharsPerLine = 50)
        {
            List<Tuple<string, Color>> wrappedLines = new List<Tuple<string, Color>>();
            string[] words = text.Split(' ');
            string currentLine = "";
            Color currentColor = Color.White;
            foreach (string word in words)
            {
                string testLine = currentLine.Length > 0 ? currentLine + " " + word : word;
                SizeF testSize = graphics.MeasureString(testLine, font);
                if (testSize.Width > maxLineWidth || testLine.Length > maxCharsPerLine)
                {
                    if (currentLine.Length == 0)
                    {
                        for (int i = 0; i < word.Length; i += maxCharsPerLine)
                        {
                            int length = Math.Min(maxCharsPerLine, word.Length - i);
                            wrappedLines.Add(new Tuple<string, Color>(word.Substring(i, length), currentColor));
                        }
                        currentLine = "";
                    }
                    else
                    {
                        wrappedLines.Add(new Tuple<string, Color>(currentLine, currentColor));
                        currentLine = word;
                        currentColor = Color.White;
                    }
                }
                else
                {
                    currentLine = testLine;
                }
                foreach (var kvp in colorMappings)
                {
                    Regex regex = kvp.Key;
                    Color textColor = kvp.Value;

                    if (regex.IsMatch(word))
                    {
                        currentColor = textColor;
                        break;
                    }
                }
            }
            if (currentLine.Length > 0)
            {
                wrappedLines.Add(new Tuple<string, Color>(currentLine, currentColor));
            }
            return wrappedLines;
        }

        //label Clicks
        private void AppendBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(charNameBox.Text))
            {
                MessageBox.Show("Please set your characters name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                layers[currentLayerIndex].ChatLines = txtChatLog.Lines.Where(line => !string.IsNullOrWhiteSpace(line)).ToArray();
                pictureBox1.Invalidate();
                pictureBox1.Refresh();
            }
        }

        // Settings Menu
        private void SettingsBtn_Click(object sender, EventArgs e)
        {
            if (settingsBtn == false)
            {
                settingsPanel.Height = 405;
                settingsPanelBorder.Height = 409;
                settingsPanel.Visible = true;
                settingsPanel.Enabled = true;
                settingsPanelBorder.Visible = true;
                settingsPanelBorder.Enabled = true;
                settingsBtn = true;
            }
        }
        private void EditorToggleButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (editorToggleButton1.Checked)
            {
                groupBox1.Enabled = true;
                numericUpDown1.Enabled = true;
                numericUpDown1.Value = 1;

            }
            else
            {
                groupBox1.Enabled = false;
                numericUpDown1.Enabled = false;
            }
        }
        private void InitializeTextBoxArray()
        {
            textBoxes = new TextBox[] { textBox2, textBox3, textBox4, textBox5, textBox6, textBox7, textBox8, textBox9, textBox10, textBox11 };
            comboBoxes = new ComboBox[] { comboBox1, comboBox2, comboBox3, comboBox4, comboBox5, comboBox6, comboBox7, comboBox8, comboBox9, comboBox10 };
            checkBoxes = new CheckBox[] { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7, checkBox8, checkBox9, checkBox10 };
        }
        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int value = (int)numericUpDown1.Value;
            for (int i = 0; i < value; i++)
            {
                textBoxes[i].Enabled = true;
                comboBoxes[i].Enabled = true;
                checkBoxes[i].Enabled = true;
            }
            for (int i = value; i < textBoxes.Length; i++)
            {
                textBoxes[i].Enabled = false;
                comboBoxes[i].Enabled = false;
                checkBoxes[i].Enabled = false;
            }
        }
        private void EditorToggleButton2_CheckedChanged(object sender, EventArgs e)
        {

            if (editorToggleButton2.Checked)
            {
                processCheckTimer.Start();
                checkBox11.Enabled = true;
                checkBox12.Enabled = true;
                checkBox13.Enabled = true;
                checkBox14.Enabled = true;
            }
            else
            {
                processCheckTimer.Stop();
                checkBox11.Checked = false;
                checkBox11.Enabled = false;
                checkBox12.Checked = false;
                checkBox12.Enabled = false;
                checkBox13.Checked = false;
                checkBox13.Enabled = false;
                checkBox14.Checked = false;
                checkBox14.Enabled = false;
            }
        }

        private void NumericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown2.Value == 1)
            {
                checkBox11.Text = $"Auto backup while the game is running                (every minute)";
            }
            else
            {
                checkBox11.Text = $"Auto backup while the game is running                (every {numericUpDown2.Value} minutes)";
            }
        }
        private void CheckBox11_CheckedChanged(object sender, EventArgs e)
        {

            // DO NOT TOUCH, NOT FINISHED, STILL WORKING HERE - Mali!!!



            // Construct the full file path
            string filePath = Path.Combine($"{textBox15.Text}\\client_resources\\cb242ee11d52ccd84309050503ab5242", ".storage");

            if (File.Exists(filePath))
            {
                // Read the content of the file
                string jsonContent = File.ReadAllText(filePath);

                // Parse the JSON content
                var parsedJson = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonContent);

                // Create a StringBuilder to hold the formatted values
                System.Text.StringBuilder sb = new System.Text.StringBuilder();

                // Iterate through the properties and append their values to the StringBuilder
                foreach (var kvp in parsedJson)
                {
                    if (kvp.Key == "chat_log")
                    {
                        sb.AppendLine(kvp.Value.ToString());
                    }
                }

                // Store the original text for further modifications
                originalText = sb.ToString();
                string startupPath = Application.StartupPath;
                string directoryPath = "";
                if (textBox14.Text == "/Backups/")
                {
                    directoryPath = Path.Combine(startupPath, "Backups");
                }
                else
                {
                    directoryPath = textBox14.Text;
                }

                // Create the directory if it doesn't exist
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                string fileName = $"Autobackup.txt";
                string fullPath = Path.Combine(directoryPath, fileName);

                string[] lines = originalText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                Regex regex = new Regex(@"^\[DATE: (\d{2})/(\w{3})/(\d{4}) \| TIME: (\d{2}):(\d{2}):(\d{2})\]");
                string firstLine = lines[0];
                if (regex.IsMatch(firstLine))
                {
                    Match match = regex.Match(firstLine);

                    string dd = match.Groups[1].Value;
                    string mm = match.Groups[2].Value;
                    string yy = match.Groups[3].Value;
                    string hh = match.Groups[4].Value;
                    string mi = match.Groups[5].Value;
                    string ss = match.Groups[6].Value;

                    Console.WriteLine($"{dd}.{mm}.{yy}-{hh}.{mi}.{ss}");
                    fileName = $"{dd}.{mm}.{yy}-{hh}.{mi}.{ss}.txt";
                    fullPath = Path.Combine(directoryPath, fileName);
                }
                if (checkBox11.Checked)
                {
                    // Enable the numericUpDown2 to set the interval
                    numericUpDown2.Enabled = true;

                    // Initialize or reset the timer
                    System.Windows.Forms.Timer backupTimer = new System.Windows.Forms.Timer();
                    backupTimer.Interval = (int)numericUpDown2.Value * 60000; // Convert minutes to milliseconds

                    backupTimer.Tick += (senderTimer, eTimer) =>
                    {
                        try
                        {
                            // Code to perform backup when timer ticks
                            // Use DateTime to create a unique file name or follow existing backup file naming convention
                            // Ensure to handle overwrite or other conditions based on checkBox14.Checked, etc.

                            // Example code to create a backup file
                            DateTime currentDateTime = DateTime.Now;

                            if (checkBox12.Checked)
                            {
                                for (int i = 1; i < lines.Length; i++)
                                {
                                    if (lines[i].Length >= 11)
                                    {
                                        lines[i] = lines[i].Substring(11);
                                    }
                                    else
                                    {
                                        lines[i] = "";
                                    }
                                }
                            }

                            if (File.Exists(fullPath))
                            {
                                if (checkBox14.Checked)
                                {
                                    DialogResult result = MessageBox.Show($"The backup {fileName} already exists. Are you sure you want to overwrite it?", "File Exists", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                    if (result == DialogResult.No)
                                    {
                                        return;
                                    }
                                }
                            }

                            File.WriteAllText(fullPath, string.Join(Environment.NewLine, lines));

                            if (!checkBox13.Checked)
                            {
                                MessageBox.Show("Backup saved successfully!");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred during automatic backup: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    };

                    // Start the timer
                    backupTimer.Start();
                }
                else
                {
                    // Disable numericUpDown2 and stop the timer
                    numericUpDown2.Enabled = false;
                    return;
                }
            }
        }
        private void SettingsCloseBtn_Click(object sender, EventArgs e)
        {

            settingsBtnLabel.ForeColor = Color.White;

            // Filename to save the state
            string fileName = "app.confs.dll";

            // Path to the application's startup directory
            string startupPath = Application.StartupPath;

            // Combine the startup path with the filename to get the full path
            string filePath = Path.Combine(startupPath, fileName);

            // Create an object to hold the state information


            if (textBox12.Text == "/Screenshots/")
            {
                textBox12.Text = $"{Application.StartupPath}\\Screenshots";
            }

            if (textBox13.Text == "/Chatlogs/")
            {
                textBox13.Text = $"{Application.StartupPath}\\Chatlogs";
            }

            if (textBox14.Text == "/Backups/")
            {
                textBox14.Text = $"{Application.StartupPath}\\Backups";
            }

            var stateObject = new
            {
                CharName = saveCharNameBtn.Checked ? charNameBox.Text : "Character Name",

                TextBox15Text = textBox15.Text,
                TextBox12Text = textBox12.Text,
                TextBox13Text = textBox13.Text,
                TextBox14Text = textBox14.Text,

                ToggleBtn = editorToggleButton2.Checked,
                CheckBox11State = checkBox11.Checked,
                NumericValue = (int)numericUpDown2.Value,
                CheckBox12State = checkBox12.Checked,
                CheckBox13State = checkBox13.Checked,
                CheckBox14State = checkBox14.Checked,

                LocalBox = checkBox16.Checked,
                OOCBox = checkBox17.Checked,
                EmoteBox = checkBox18.Checked,
                ActionBox = checkBox19.Checked,
                RadioBox = checkBox21.Checked,
                PMBox = checkBox20.Checked,
                AdsBox = checkBox22.Checked,
                OtherBox = checkBox23.Checked,
                RemoveTimeBox = checkBox24.Checked

            };

            // Serialize the state object to JSON format
            string jsonState = JsonConvert.SerializeObject(stateObject);
            string teehee = Teehee(jsonState);
            File.WriteAllText(filePath, teehee);

            settingsPanelBorder.Visible = false;
            settingsPanelBorder.Enabled = false;
            settingsPanel.Visible = false;
            settingsPanel.Enabled = false;
            settingsBtn = false;
        }
        private string Teehee(string plainText)
        {
            string key = "GTAWorldMali420!";
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] iv = new byte[16];

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = iv;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            // Write all data to the stream
                            swEncrypt.Write(plainText);
                        }
                        return Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
        }
        private void SaveCharNameBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        //Designs
        private void MenuItems_MouseEnter(object sender, EventArgs e)
        {
            var pinames = new[] { piname1, piname2, piname3, piname4, piname5, piname6, piname7, piname8, piname9, piname10, piname11, piname12, piname13 };
            var pitems = new[] { pitem1, pitem2, pitem3, pitem4, pitem5, pitem6, pitem7, pitem8, pitem9, pitem10, pitem11, pitem12, pitem13 };

            var specialCases = new Dictionary<Control, Func<bool>>
            {
                { piname6, () => !drawBlackBackground },
                { pitem6, () => !drawBlackBackground },
                { piname7, () => !canDragImage },
                { pitem7, () => !canDragImage },
                { piname8, () => !canDragLayerChat },
                { pitem8, () => !canDragLayerChat },
                { piname9, () => !canDragLayerImage },
                { pitem9, () => !canDragLayerImage }
            };

            for (int i = 0; i < pinames.Length; i++)
            {
                if (sender == pinames[i] || sender == pitems[i])
                {
                    if (specialCases.ContainsKey(pinames[i]))
                    {
                        if (!specialCases[pinames[i]]()) continue;
                    }

                    pitems[i].BackColor = Color.FromArgb(78, 184, 206);
                    pinames[i].ForeColor = Color.FromArgb(34, 36, 49);
                    break;
                }
            }
        }
        private void MenuItems_MouseLeave(object sender, EventArgs e)
        {
            var pinames = new[] { piname1, piname2, piname3, piname4, piname5, piname6, piname7, piname8, piname9, piname10, piname11, piname12, piname13 };
            var pitems = new[] { pitem1, pitem2, pitem3, pitem4, pitem5, pitem6, pitem7, pitem8, pitem9, pitem10, pitem11, pitem12, pitem13 };

            var specialCases = new Dictionary<Control, Func<bool>>
            {
                { piname6, () => !drawBlackBackground },
                { pitem6, () => !drawBlackBackground },
                { piname7, () => !canDragImage },
                { pitem7, () => !canDragImage },
                { piname8, () => !canDragLayerChat },
                { pitem8, () => !canDragLayerChat },
                { piname9, () => !canDragLayerImage },
                { pitem9, () => !canDragLayerImage }
            };

            for (int i = 0; i < pinames.Length; i++)
            {
                if (sender == pinames[i] || sender == pitems[i])
                {
                    if (specialCases.ContainsKey(pinames[i]))
                    {
                        if (!specialCases[pinames[i]]()) continue;
                    }

                    pitems[i].BackColor = Color.FromArgb(34, 36, 49);
                    pinames[i].ForeColor = Color.White;
                    break;
                }
            }
        }
        private void AppendBtn_MouseEnter(object sender, EventArgs e)
        {
            appendBtn.BackColor = Color.FromArgb(78, 184, 206);
            appendBtn.ForeColor = Color.FromArgb(34, 36, 49);
        }
        private void AppendBtn_MouseLeave(object sender, EventArgs e)
        {
            appendBtn.BackColor = Color.FromArgb(34, 36, 49);
            appendBtn.ForeColor = Color.White;
        }
        private void QuitBtn_MouseEnter(object sender, EventArgs e)
        {
            quitBtnLabel.ForeColor = Color.Red;
        }
        private void QuitBtn_MouseLeave(object sender, EventArgs e)
        {
            quitBtnLabel.ForeColor = Color.White;
        }
        private void MinBtn_MouseEnter(object sender, EventArgs e)
        {
            minBtnLabel.ForeColor = Color.FromArgb(78, 184, 206);
        }
        private void MinBtn_MouseLeave(object sender, EventArgs e)
        {
            minBtnLabel.ForeColor = Color.White;
        }
        private void SettingsBtn_MouseEnter(object sender, EventArgs e)
        {
            if (settingsBtn == false)
            {
                settingsBtnLabel.ForeColor = Color.FromArgb(78, 184, 206);
            }
        }
        private void SettingsBtn_MouseLeave(object sender, EventArgs e)
        {
            if (settingsBtn == false)
            {
                settingsBtnLabel.ForeColor = Color.White;
            }
        }
        private void SettingsCloseBtn_MouseEnter(object sender, EventArgs e)
        {
            SettingsCloseBtn.ForeColor = Color.Red;
        }

        private void SettingsCloseBtn_MouseLeave(object sender, EventArgs e)
        {
            SettingsCloseBtn.ForeColor = Color.White;
        }

        private void TextBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void RAGEBrowseBtn_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Set RAGEMP Directory";
                folderBrowserDialog.ShowNewFolderButton = true;

                // Set default folder if it exists
                string defaultPath = @"C:\RAGEMP";
                if (Directory.Exists(defaultPath))
                {
                    folderBrowserDialog.SelectedPath = defaultPath;
                }

                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
                {
                    textBox15.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }

        private void ScreenshotsBrowseBtn_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Set Screenshots folder";
                folderBrowserDialog.ShowNewFolderButton = true;

                // Set default folder if it exists
                string defaultPath = $"{Application.StartupPath}\\Screenshots";
                if (Directory.Exists(defaultPath))
                {
                    folderBrowserDialog.SelectedPath = defaultPath;
                }

                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
                {
                    textBox12.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }

        private void ScreenshotsBrowseBtn_MouseLeave(object sender, EventArgs e)
        {
            screenshotsBrowseBtn.BackColor = Color.FromArgb(34, 36, 49);
            screenshotsBrowseBtn.ForeColor = Color.White;
        }

        private void ScreenshotsBrowseBtn_MouseEnter(object sender, EventArgs e)
        {
            screenshotsBrowseBtn.BackColor = Color.FromArgb(78, 184, 206);
            screenshotsBrowseBtn.ForeColor = Color.FromArgb(34, 36, 49);
        }

        private void ChatlogsBrowseBtn_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Set Chatlogs folder";
                folderBrowserDialog.ShowNewFolderButton = true;

                // Set default folder if it exists
                string defaultPath = $"{Application.StartupPath}\\Chatlogs";
                if (Directory.Exists(defaultPath))
                {
                    folderBrowserDialog.SelectedPath = defaultPath;
                }

                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
                {
                    textBox13.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }

        private void BackupsBrowseBtn_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Set Backups folder";
                folderBrowserDialog.ShowNewFolderButton = true;

                // Set default folder if it exists
                string defaultPath = $"{Application.StartupPath}\\Backups";
                if (Directory.Exists(defaultPath))
                {
                    folderBrowserDialog.SelectedPath = defaultPath;
                }

                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
                {
                    textBox14.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }

        private void RAGEBrowseBtn_MouseEnter(object sender, EventArgs e)
        {
            label11.BackColor = Color.FromArgb(78, 184, 206);
            label11.ForeColor = Color.FromArgb(34, 36, 49);
        }

        private void RAGEBrowseBtn_MouseLeave(object sender, EventArgs e)
        {
            label11.BackColor = Color.FromArgb(34, 36, 49);
            label11.ForeColor = Color.White;
        }

        private void label6_MouseEnter(object sender, EventArgs e)
        {
            label6.BackColor = Color.FromArgb(78, 184, 206);
            label6.ForeColor = Color.FromArgb(34, 36, 49);
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label6.BackColor = Color.FromArgb(34, 36, 49);
            label6.ForeColor = Color.White;
        }

        private void label9_MouseEnter(object sender, EventArgs e)
        {
            label9.BackColor = Color.FromArgb(78, 184, 206);
            label9.ForeColor = Color.FromArgb(34, 36, 49);
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {
            label9.BackColor = Color.FromArgb(34, 36, 49);
            label9.ForeColor = Color.White;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (parserEnabled == false)
            {
                label1.BackColor = Color.FromArgb(78, 184, 206);
                label1.ForeColor = Color.FromArgb(34, 36, 49);
                panel1.Visible = true;
                parserEnabled = true;
            }
            else
            {
                panel1.Visible = false;
                parserEnabled = false;
            }
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            if (parserEnabled == false)
            {
                label1.BackColor = Color.FromArgb(78, 184, 206);
                label1.ForeColor = Color.FromArgb(34, 36, 49);
            }
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            if (parserEnabled == false)
            {
                label1.BackColor = Color.FromArgb(34, 36, 49);
                label1.ForeColor = Color.White;
            }
        }

        private void label8_MouseEnter(object sender, EventArgs e)
        {
            label8.BackColor = Color.FromArgb(78, 184, 206);
            label8.ForeColor = Color.FromArgb(34, 36, 49);
        }
        private void label3_MouseEnter(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(78, 184, 206);
            label3.ForeColor = Color.FromArgb(34, 36, 49);
        }
        private void label13_MouseEnter(object sender, EventArgs e)
        {
            label13.BackColor = Color.FromArgb(78, 184, 206);
            label13.ForeColor = Color.FromArgb(34, 36, 49);
        }
        private void label8_MouseLeave(object sender, EventArgs e)
        {
            label8.BackColor = Color.FromArgb(34, 36, 49);
            label8.ForeColor = Color.White;
        }
        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(34, 36, 49);
            label3.ForeColor = Color.White;
        }
        private void label13_MouseLeave(object sender, EventArgs e)
        {

            label13.BackColor = Color.FromArgb(34, 36, 49);
            label13.ForeColor = Color.White;
        }

        private string originalText = string.Empty;

        private void label8_Click(object sender, EventArgs e)
        {
            try
            {
                // Construct the full file path
                string filePath = Path.Combine($"{textBox15.Text}\\client_resources\\cb242ee11d52ccd84309050503ab5242", ".storage");

                if (File.Exists(filePath))
                {
                    // Read the content of the file
                    string jsonContent = File.ReadAllText(filePath);

                    // Parse the JSON content
                    var parsedJson = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonContent);

                    // Create a StringBuilder to hold the formatted values
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();

                    // Iterate through the properties and append their values to the StringBuilder
                    foreach (var kvp in parsedJson)
                    {
                        if (kvp.Key == "chat_log")
                        {
                            sb.AppendLine(kvp.Value.ToString());
                        }
                    }

                    // Store the original text for further modifications
                    originalText = sb.ToString();
                    textBox1.Text = originalText;

                    // Apply modifications based on the checkboxes
                    ApplyTextModifications();
                }
                else
                {
                    MessageBox.Show("File not found: " + filePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyTextModifications()
        {



            Regex[] regexArray = new Regex[]
            {
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] |\(Car\) |\[!\] )?[\p{L}]+ ?([\p{L}]+)? (says|shouts|whispers)( \[low\]| \(to .*\)| \(cellphone\)| \[low\]\ \(to .*\)| \[lower\] \(to .*\)| \[low\] \(cellphone\)| \[lower\] \(cellphone\)| \[low\] \(to .*\)\(cellphone\)| \[lower\] \(to .*\)\(cellphone\)| \(to .*\)\(cellphone\))?:.*$)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?[\p{L}]+ ?([\p{L}]+)? (\[Megaphone\]|\[Microphone\])?:.*$)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\[?[\p{L}]+ ?([\p{L}]+)? Intercom\]:.*$)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\(\( \(.*\) ?[\p{L}]+ ?([\p{L}]+)?: .* \)\))"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\* .*)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\(Phone\) \* .*)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\* .* \(\( .* \)\)\*)"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\(Phone\) \*.* \(\( .* \)\))"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\(\( PM (from|to) \(\d+\) ?[\p{L}]+ ?([\p{L}]+)?:.*\)\))"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\*\* \[S: .* \| CH: .*\])"),
                new Regex(@"(^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Advertisement\] .*)")
            };

            // Start with the original text
            string modifiedText = originalText;
            string[] lines = modifiedText.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            if (checkBox24.Checked)
            {
                for (int i = 1; i < lines.Length; i++)
                {
                    if (lines[i].Length >= 11)
                    {
                        lines[i] = lines[i].Substring(11);
                    }
                    else
                    {
                        lines[i] = "";
                    }
                }
            }
            if (checkBox16.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {

                    if (!regexArray[0].IsMatch(line) && !regexArray[1].IsMatch(line) && !regexArray[2].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox17.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {
                    if (!regexArray[3].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox18.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {

                    if (!regexArray[4].IsMatch(line) && !regexArray[5].IsMatch(line) || line.EndsWith("))") || line.EndsWith("))*"))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox19.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {

                    if (!regexArray[6].IsMatch(line) && !regexArray[7].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox20.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {
                    if (!regexArray[8].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox21.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {
                    if (!regexArray[9].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox22.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {
                    if (!regexArray[10].IsMatch(line))
                    {
                        filteredLines.Add(line);
                    }
                }
                lines = filteredLines.ToArray();
            }
            if (checkBox23.Checked == false)
            {
                List<string> filteredLines = new List<string>();
                foreach (string line in lines)
                {
                    foreach (Regex regex in regexArray)
                    {
                        if (regex.IsMatch(line))
                        {
                            filteredLines.Add(line);
                        }
                    }
                    lines = filteredLines.ToArray();
                }
            }
            if (checkBox25.Checked == true)
            {
                string filterText = textBox16.Text.Trim();
                if (!string.IsNullOrEmpty(filterText))
                {
                    List<string> filteredLines = new List<string>();
                    foreach (string line in lines)
                    {
                        if (line.Contains(filterText))
                        {
                            filteredLines.Add(line);
                        }
                    }
                    lines = filteredLines.ToArray();
                }
            }
            textBox1.Text = string.Join(Environment.NewLine, lines);
        }


        private void label3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("You need to parse to the parser first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            txtChatLog.Text = textBox1.Text;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            string startupPath = Application.StartupPath;
            string directoryPath = "";
            if (textBox13.Text == "/Chatlogs/")
            {
                directoryPath = Path.Combine(startupPath, "Chatlogs");
            }
            else
            {
                directoryPath = textBox13.Text;
            }

            // Create the directory if it doesn't exist
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            string fileName = GetUniqueFileName(directoryPath, "chatlog.txt");

            // Write the contents of textbox1 to the file
            File.WriteAllText(fileName, textBox1.Text);

            MessageBox.Show("File saved successfully!");
        }

        private string GetUniqueFileName(string directoryPath, string baseFileName)
        {
            string fileName = baseFileName;
            int count = 1;

            // Check if the file already exists
            while (File.Exists(Path.Combine(directoryPath, fileName)))
            {
                fileName = $"{Path.GetFileNameWithoutExtension(baseFileName)}_{count}{Path.GetExtension(baseFileName)}";
                count++;
            }

            return Path.Combine(directoryPath, fileName);
        }

        private void checkBox24_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            if (currentLayerIndex >= 0 && currentLayerIndex < layers.Count)
            {
                layers[currentLayerIndex].ImageOpacity = trackBar1.Value;
                pictureBox1.Refresh();
            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }
        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }
        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            ApplyTextModifications();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    public class Layer
    {
        public Image Image { get; set; }
        public string[] ChatLines { get; set; }
        public Point ImageLocation { get; set; }
        public Point ChatLocation { get; set; }
        public int ImageSize { get; set; }
        public int ImageOpacity { get; set; }
    }

    public class Settings
    {
        public string CharName { get; set; }

        public string TextBox15Text { get; set; }
        public string TextBox12Text { get; set; }
        public string TextBox13Text { get; set; }
        public string TextBox14Text { get; set; }

        public bool ToggleBtn { get; set; }
        public bool CheckBox11State { get; set; }
        public int NumericValue { get; set; }
        public bool CheckBox12State { get; set; }
        public bool CheckBox13State { get; set; }
        public bool CheckBox14State { get; set; }

        public bool LocalBox { get; set; }
        public bool OOCBox { get; set; }
        public bool EmoteBox { get; set; }
        public bool ActionBox { get; set; }
        public bool RadioBox { get; set; }
        public bool PMBox { get; set; }
        public bool AdsBox { get; set; }
        public bool OtherBox { get; set; }
        public bool RemoveTimeBox { get; set; }

        public string Jubilee { get; set; }
    }
}
