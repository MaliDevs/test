﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace SS_Editor.CustomControls
{
    public class EditorCheckBox : CheckBox
    {
        public EditorCheckBox()
        {
            this.EnabledChanged += EditorCheckBox_EnabledChanged;
        }

        private void EditorCheckBox_EnabledChanged(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (!this.Enabled)
            {
                // Calculate the position of the checkmark
                Size checkBoxSize = CheckBoxRenderer.GetGlyphSize(e.Graphics, CheckBoxState.UncheckedNormal);
                int textOffsetX = checkBoxSize.Width + 3; // Adding some padding between the checkmark and the text
                int textOffsetY = -2; // Move text up by 1 pixel

                // Calculate the rectangle for the text
                Rectangle textRect = new Rectangle(
                    this.ClientRectangle.X + textOffsetX,
                    this.ClientRectangle.Y + textOffsetY,
                    this.ClientRectangle.Width - textOffsetX,
                    this.ClientRectangle.Height
                );

                TextFormatFlags flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter;
                TextRenderer.DrawText(e.Graphics, this.Text, this.Font, textRect, Color.Gray, flags);
            }
        }
    }
}
