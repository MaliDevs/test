﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SS_Editor
{
    public partial class Login : Form
    {

        private const string DiscordOAuthUrl = "https://discord.com/oauth2/authorize?client_id=1257136011431907453&response_type=code&redirect_uri=http%3A%2F%2F164.152.23.174%2Fdisidcallback%2Fdiscord&scope=identify+email";
        public Login()
        {
            InitializeComponent();
            Process.Start(new ProcessStartInfo
            {
                FileName = DiscordOAuthUrl,
                UseShellExecute = true
            });
        }
    }
}
