﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SS_Editor
{
    public partial class TestSizingForm : Form
    {
        private bool isDragging = false;
        private Point dragStartPoint = Point.Empty;

        public TestSizingForm()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Ensure the PictureBox is set to Zoom mode
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

            // Set up the button click event
            button1.Text = "Choose Image";
            button1.Click += Button1_Click;

            // Handle mouse events for dragging
            pictureBox1.MouseDown += PictureBox1_MouseDown;
            pictureBox1.MouseMove += PictureBox1_MouseMove;
            pictureBox1.MouseUp += PictureBox1_MouseUp;

            // Handle key down event for resizing
            this.KeyDown += TestSizingForm_KeyDown;
            this.KeyPreview = true; // Ensure the form captures key events before controls
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg;*.png;*.bmp"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;
                Image image = Image.FromFile(imagePath);
                pictureBox1.Image = image;

                // Calculate the appropriate size for the PictureBox to fit within the panel while maintaining aspect ratio
                Size newSize = CalculateImageSizeToFitPanel(image.Size, panel1.ClientSize);
                pictureBox1.Size = newSize;

                // Center the PictureBox in the panel
                pictureBox1.Location = new Point(
                    (panel1.ClientSize.Width - pictureBox1.Width) / 2,
                    (panel1.ClientSize.Height - pictureBox1.Height) / 2
                );
            }
        }

        private Size CalculateImageSizeToFitPanel(Size imageSize, Size panelSize)
        {
            float imageAspectRatio = (float)imageSize.Width / imageSize.Height;
            float panelAspectRatio = (float)panelSize.Width / panelSize.Height;

            int newWidth, newHeight;

            if (imageAspectRatio > panelAspectRatio)
            {
                // The image is wider relative to the panel
                newWidth = panelSize.Width;
                newHeight = (int)(panelSize.Width / imageAspectRatio);
            }
            else
            {
                // The image is taller relative to the panel
                newHeight = panelSize.Height;
                newWidth = (int)(panelSize.Height * imageAspectRatio);
            }

            return new Size(newWidth, newHeight);
        }

        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                dragStartPoint = e.Location;
            }
        }

        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point currentScreenPos = pictureBox1.PointToScreen(e.Location);
                Point newPictureBoxLocation = panel1.PointToClient(currentScreenPos);

                // Calculate the new location and keep it within the bounds of the panel
                int newX = newPictureBoxLocation.X - dragStartPoint.X;
                int newY = newPictureBoxLocation.Y - dragStartPoint.Y;

                // Ensure the PictureBox stays within the panel's bounds
                newX = Math.Max(newX, 0);
                newY = Math.Max(newY, 0);

                if (newX + pictureBox1.Width > panel1.ClientSize.Width)
                {
                    newX = panel1.ClientSize.Width - pictureBox1.Width;
                }

                if (newY + pictureBox1.Height > panel1.ClientSize.Height)
                {
                    newY = panel1.ClientSize.Height - pictureBox1.Height;
                }

                pictureBox1.Location = new Point(newX, newY);
            }
        }

        private void PictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void TestSizingForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Oemplus) // CTRL + +
            {
                ResizePictureBox(1.01); // Increase size by 1%
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.OemMinus) // CTRL + -
            {
                ResizePictureBox(0.99); // Decrease size by 1%
                e.Handled = true;
            }
        }

        private void ResizePictureBox(double scaleFactor)
        {
            int newWidth = (int)(pictureBox1.Width * scaleFactor);
            int newHeight = (int)(pictureBox1.Height * scaleFactor);

            if (newWidth > 0 && newHeight > 0)
            {
                pictureBox1.Size = new Size(newWidth, newHeight);

                // Ensure the PictureBox stays within the panel's bounds after resizing
                if (pictureBox1.Right > panel1.ClientSize.Width)
                {
                    pictureBox1.Left = panel1.ClientSize.Width - pictureBox1.Width;
                }

                if (pictureBox1.Bottom > panel1.ClientSize.Height)
                {
                    pictureBox1.Top = panel1.ClientSize.Height - pictureBox1.Height;
                }

                pictureBox1.Left = Math.Max(pictureBox1.Left, 0);
                pictureBox1.Top = Math.Max(pictureBox1.Top, 0);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
