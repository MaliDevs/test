﻿using Newtonsoft.Json;
using System;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Text;
using System.Text.RegularExpressions;

namespace SS_Editor
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private async void Login_Load(object sender, EventArgs e)
        {

            // Load saved settings from a configuration file
            string fileName = "config.conf";
            string filePath = Path.Combine(Application.StartupPath, fileName);
            if (File.Exists(filePath))
            {
                // Decrypt the saved settings and populate the form fields
                string encryptedJsonState = File.ReadAllText(filePath);
                string jsonState = Decrypt(encryptedJsonState);
                if (!string.IsNullOrEmpty(jsonState))
                {
                    Settings2 loadedSettings = JsonConvert.DeserializeObject<Settings2>(jsonState);
                    if (loadedSettings != null)
                    {
                        toggleBtn.Checked = loadedSettings.SaveSettings;
                        discordBox.Text = loadedSettings.Discord;
                        licenseBox.Text = loadedSettings.License;
                    }
                }
            }
        }

        // Decrypts a given encrypted text using AES encryption
        private string Decrypt(string encryptedText)
        {
            string key = "GTAWorldMali420!";
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] iv = new byte[16];
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = iv;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(encryptedText)))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            string decryptedText = srDecrypt.ReadToEnd();
                            return decryptedText;
                        }
                    }
                }
            }
        }

        // Encrypts a given plain text using AES encryption
        private string Teehee(string plainText)
        {
            string key = "GTAWorldMali420!";
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] iv = new byte[16];
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = iv;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                        return Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
        }

        // Handles the login button click event
        private async void LoginBtn_Click(object sender, EventArgs e)
        {
            // Get the values from the text boxes
            string username = discordBox.Text;
            string licenseKey = licenseBox.Text;

            // Validate input
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(licenseKey))
            {
                MessageBox.Show("Username and License Key are required.");
                return;
            }

            // URL of the PHP script
            string url = "https://api.screenshot-magician.store/test/callback.php";

            // Create the HttpClient
            using (HttpClient client = new HttpClient())
            {
                // Create the content to be posted
                var formData = new MultipartFormDataContent();
                formData.Add(new StringContent(username), "username");
                formData.Add(new StringContent(licenseKey), "license_key");

                try
                {
                    // Send the POST request
                    HttpResponseMessage response = await client.PostAsync(url, formData);

                    // Check if the response was successful
                    if (!response.IsSuccessStatusCode)
                    {
                        MessageBox.Show($"Server returned an error: {response.StatusCode} - {response.ReasonPhrase}");
                        return;
                    }

                    // Read the response
                    string responseBody = await response.Content.ReadAsStringAsync();

                    // Print the raw response for debugging

                    // Normalize the response to handle pretty-print formatting
                    string normalizedResponse = Regex.Replace(responseBody, @"\s+", "");

                    // Extract status and message using regex
                    string statusPattern = @"""status"":\s*""(.*?)""";
                    string messagePattern = @"""message"":\s*""(.*?)""";

                    string status = Regex.Match(normalizedResponse, statusPattern).Groups[1].Value;
                    string message = Regex.Match(normalizedResponse, messagePattern).Groups[1].Value;

                    // Handle the response based on extracted values
                    if (status == "fail")
                    {
                        switch (message)
                        {
                            case "Usernotloggedin":
                                MessageBox.Show("You should do /login on the discord server first.");
                                break;
                            case "LicenseIPmismatch":
                                MessageBox.Show("This license key doesn't belong to you.\nIf you believe this to be an error, open a support ticket.");
                                break;
                            case "UserIPmismatch":
                                MessageBox.Show("This username doesn't belong to you.\nIf you believe this to be an error, open a support ticket.");
                                break;
                            case "Invalidlicenseorusername":
                                MessageBox.Show("Invalid license or username.");
                                break;
                            default:
                                MessageBox.Show("Unexpected error: " + message);
                                break;
                        }
                    }
                    else if (status == "ok")
                    {
                        MessageBox.Show("logged in as " + message + "!");
                        Form1 form1 = new Form1();
                        form1.Show();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("Unexpected response: " + responseBody);
                    }
                }
                catch (HttpRequestException)
                {
                    MessageBox.Show($"Error: Not connected to the internet.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }

            // Save the current settings to a configuration file
            string fileName = "config.conf";
            string startupPath = Application.StartupPath;
            string filePath = Path.Combine(startupPath, fileName);
            var stateObject = new
            {
                SaveSettings = toggleBtn.Checked,
                Discord = toggleBtn.Checked ? discordBox.Text : "",
                License = toggleBtn.Checked ? licenseBox.Text : "",
            };
            string jsonState = JsonConvert.SerializeObject(stateObject);
            string teehee = Teehee(jsonState);
            File.WriteAllText(filePath, teehee);
        }


        // Change the login button text color on mouse enter
        private void LoginBtn_MouseEnter(object sender, EventArgs e)
        {
            loginBtn.ForeColor = Color.FromArgb(34, 36, 49);
        }

        // Reset the login button text color on mouse leave
        private void LoginBtn_MouseLeave(object sender, EventArgs e)
        {
            loginBtn.ForeColor = Color.White;
        }

        // Change the close button text color on mouse enter
        private void CloseBtn_MouseEnter(object sender, EventArgs e)
        {
            closeBtn.ForeColor = Color.Red;
        }

        // Reset the close button text color on mouse leave
        private void CloseBtn_MouseLeave(object sender, EventArgs e)
        {
            closeBtn.ForeColor = Color.White;
        }

        // Close the application when the close button is clicked
        private void closeBtn_Click(object sender, EventArgs e)
        {
            string fileName = "config.conf";
            string startupPath = Application.StartupPath;
            string filePath = Path.Combine(startupPath, fileName);
            var stateObject = new
            {
                SaveSettings = toggleBtn.Checked,
                Discord = toggleBtn.Checked ? discordBox.Text : "",
                License = toggleBtn.Checked ? licenseBox.Text : "",
            };
            string jsonState = JsonConvert.SerializeObject(stateObject);
            string teehee = Teehee(jsonState);
            File.WriteAllText(filePath, teehee);
            this.Close();
        }
    }

    // Class to represent the settings to be saved
    public class Settings2
    {
        public bool SaveSettings { get; set; }
        public string Discord { get; set; }
        public string License { get; set; }
    }
}