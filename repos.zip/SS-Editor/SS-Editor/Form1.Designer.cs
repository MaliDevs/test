﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SS_Editor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.trackBarImageSize = new System.Windows.Forms.TrackBar();
            this.imageSizeLabel = new System.Windows.Forms.Label();
            this.txtChatLog = new System.Windows.Forms.TextBox();
            this.comboBoxLayers = new System.Windows.Forms.ComboBox();
            this.trackBarLayerSize = new System.Windows.Forms.TrackBar();
            this.menuBtnLabel = new System.Windows.Forms.Label();
            this.menuBtnSymbol = new System.Windows.Forms.Label();
            this.quitBtnLabel = new System.Windows.Forms.Label();
            this.menuPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pitem13 = new System.Windows.Forms.Panel();
            this.piname13 = new System.Windows.Forms.Label();
            this.pitem5 = new System.Windows.Forms.Panel();
            this.piname5 = new System.Windows.Forms.Label();
            this.pitem12 = new System.Windows.Forms.Panel();
            this.piname12 = new System.Windows.Forms.Label();
            this.pitem1 = new System.Windows.Forms.Panel();
            this.piname1 = new System.Windows.Forms.Label();
            this.pitem6 = new System.Windows.Forms.Panel();
            this.piname6 = new System.Windows.Forms.Label();
            this.pitem4 = new System.Windows.Forms.Panel();
            this.piname4 = new System.Windows.Forms.Label();
            this.pitem9 = new System.Windows.Forms.Panel();
            this.piname9 = new System.Windows.Forms.Label();
            this.pitem11 = new System.Windows.Forms.Panel();
            this.piname11 = new System.Windows.Forms.Label();
            this.pitem2 = new System.Windows.Forms.Panel();
            this.piname2 = new System.Windows.Forms.Label();
            this.pitem3 = new System.Windows.Forms.Panel();
            this.piname3 = new System.Windows.Forms.Label();
            this.pitem8 = new System.Windows.Forms.Panel();
            this.piname8 = new System.Windows.Forms.Label();
            this.pitem7 = new System.Windows.Forms.Panel();
            this.piname7 = new System.Windows.Forms.Label();
            this.pitem10 = new System.Windows.Forms.Panel();
            this.piname10 = new System.Windows.Forms.Label();
            this.layerSelectionLabel = new System.Windows.Forms.Label();
            this.layerSizeLabel = new System.Windows.Forms.Label();
            this.trackBarLayerPanel = new System.Windows.Forms.Panel();
            this.trackBarImagePanel = new System.Windows.Forms.Panel();
            this.appTitle = new System.Windows.Forms.Label();
            this.appendBtn = new System.Windows.Forms.Label();
            this.minBtnLabel = new System.Windows.Forms.Label();
            this.settingsBtnLabel = new System.Windows.Forms.Label();
            this.settingsPanel = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.screenshotsBrowseBtn = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.SettingsCloseBtn = new System.Windows.Forms.Label();
            this.settingsLabel = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.saveCharNameBtn = new System.Windows.Forms.CheckBox();
            this.charLabel = new System.Windows.Forms.Label();
            this.charNameBox = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.addCharLabel = new System.Windows.Forms.Label();
            this.settingsPanelBorder = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.checkBox11 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox14 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox13 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox12 = new SS_Editor.CustomControls.EditorCheckBox();
            this.editorToggleButton2 = new SS_EDITOR.CustomControl.EditorToggleButton();
            this.checkBox10 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox9 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox8 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox7 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox6 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox5 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox4 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox3 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox2 = new SS_Editor.CustomControls.EditorCheckBox();
            this.checkBox1 = new SS_Editor.CustomControls.EditorCheckBox();
            this.editorToggleButton1 = new SS_EDITOR.CustomControl.EditorToggleButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarImageSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarLayerSize)).BeginInit();
            this.menuPanel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pitem13.SuspendLayout();
            this.pitem5.SuspendLayout();
            this.pitem12.SuspendLayout();
            this.pitem1.SuspendLayout();
            this.pitem6.SuspendLayout();
            this.pitem4.SuspendLayout();
            this.pitem9.SuspendLayout();
            this.pitem11.SuspendLayout();
            this.pitem2.SuspendLayout();
            this.pitem3.SuspendLayout();
            this.pitem8.SuspendLayout();
            this.pitem7.SuspendLayout();
            this.pitem10.SuspendLayout();
            this.trackBarLayerPanel.SuspendLayout();
            this.trackBarImagePanel.SuspendLayout();
            this.settingsPanel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox1.Location = new System.Drawing.Point(7, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 600);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBox1_Paint);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PictureBox1_MouseUp);
            // 
            // trackBarImageSize
            // 
            this.trackBarImageSize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.trackBarImageSize.Location = new System.Drawing.Point(-5, 1);
            this.trackBarImageSize.Maximum = 800;
            this.trackBarImageSize.Minimum = 100;
            this.trackBarImageSize.Name = "trackBarImageSize";
            this.trackBarImageSize.Size = new System.Drawing.Size(226, 45);
            this.trackBarImageSize.TabIndex = 3;
            this.trackBarImageSize.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarImageSize.Value = 400;
            this.trackBarImageSize.Scroll += new System.EventHandler(this.TrackBarImageSize_Scroll);
            // 
            // imageSizeLabel
            // 
            this.imageSizeLabel.AutoSize = true;
            this.imageSizeLabel.BackColor = System.Drawing.Color.Transparent;
            this.imageSizeLabel.ForeColor = System.Drawing.Color.White;
            this.imageSizeLabel.Location = new System.Drawing.Point(66, 22);
            this.imageSizeLabel.Name = "imageSizeLabel";
            this.imageSizeLabel.Size = new System.Drawing.Size(59, 13);
            this.imageSizeLabel.TabIndex = 5;
            this.imageSizeLabel.Text = "Image Size";
            // 
            // txtChatLog
            // 
            this.txtChatLog.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txtChatLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtChatLog.Location = new System.Drawing.Point(813, 43);
            this.txtChatLog.Multiline = true;
            this.txtChatLog.Name = "txtChatLog";
            this.txtChatLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtChatLog.Size = new System.Drawing.Size(450, 600);
            this.txtChatLog.TabIndex = 7;
            // 
            // comboBoxLayers
            // 
            this.comboBoxLayers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBoxLayers.ForeColor = System.Drawing.Color.White;
            this.comboBoxLayers.FormattingEnabled = true;
            this.comboBoxLayers.Location = new System.Drawing.Point(1192, 648);
            this.comboBoxLayers.Name = "comboBoxLayers";
            this.comboBoxLayers.Size = new System.Drawing.Size(71, 21);
            this.comboBoxLayers.TabIndex = 18;
            this.comboBoxLayers.SelectedIndexChanged += new System.EventHandler(this.ComboBoxLayers_SelectedIndexChanged);
            // 
            // trackBarLayerSize
            // 
            this.trackBarLayerSize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.trackBarLayerSize.Location = new System.Drawing.Point(-5, -1);
            this.trackBarLayerSize.Maximum = 800;
            this.trackBarLayerSize.Minimum = 100;
            this.trackBarLayerSize.Name = "trackBarLayerSize";
            this.trackBarLayerSize.Size = new System.Drawing.Size(226, 45);
            this.trackBarLayerSize.TabIndex = 21;
            this.trackBarLayerSize.TabStop = false;
            this.trackBarLayerSize.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarLayerSize.Value = 400;
            this.trackBarLayerSize.Scroll += new System.EventHandler(this.TrackBarLayerSize_Scroll);
            this.trackBarLayerSize.ValueChanged += new System.EventHandler(this.TrackBarLayerSize_ValueChanged);
            // 
            // menuBtnLabel
            // 
            this.menuBtnLabel.AutoSize = true;
            this.menuBtnLabel.BackColor = System.Drawing.Color.Transparent;
            this.menuBtnLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuBtnLabel.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtnLabel.ForeColor = System.Drawing.Color.White;
            this.menuBtnLabel.Location = new System.Drawing.Point(40, 12);
            this.menuBtnLabel.Name = "menuBtnLabel";
            this.menuBtnLabel.Size = new System.Drawing.Size(61, 24);
            this.menuBtnLabel.TabIndex = 2;
            this.menuBtnLabel.Text = "Menu";
            this.menuBtnLabel.Click += new System.EventHandler(this.Menu_Click);
            // 
            // menuBtnSymbol
            // 
            this.menuBtnSymbol.AutoSize = true;
            this.menuBtnSymbol.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuBtnSymbol.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtnSymbol.ForeColor = System.Drawing.Color.White;
            this.menuBtnSymbol.Location = new System.Drawing.Point(7, 4);
            this.menuBtnSymbol.Name = "menuBtnSymbol";
            this.menuBtnSymbol.Size = new System.Drawing.Size(42, 36);
            this.menuBtnSymbol.TabIndex = 1;
            this.menuBtnSymbol.Text = "⁝☰";
            this.menuBtnSymbol.Click += new System.EventHandler(this.Menu_Click);
            // 
            // quitBtnLabel
            // 
            this.quitBtnLabel.AutoSize = true;
            this.quitBtnLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.quitBtnLabel.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quitBtnLabel.ForeColor = System.Drawing.Color.White;
            this.quitBtnLabel.Location = new System.Drawing.Point(1245, 4);
            this.quitBtnLabel.Name = "quitBtnLabel";
            this.quitBtnLabel.Size = new System.Drawing.Size(24, 24);
            this.quitBtnLabel.TabIndex = 0;
            this.quitBtnLabel.Text = "X";
            this.quitBtnLabel.Click += new System.EventHandler(this.QuitBtn_Click);
            this.quitBtnLabel.MouseEnter += new System.EventHandler(this.QuitBtn_MouseEnter);
            this.quitBtnLabel.MouseLeave += new System.EventHandler(this.QuitBtn_MouseLeave);
            // 
            // menuPanel
            // 
            this.menuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.menuPanel.Controls.Add(this.tableLayoutPanel1);
            this.menuPanel.Location = new System.Drawing.Point(0, 42);
            this.menuPanel.Name = "menuPanel";
            this.menuPanel.Size = new System.Drawing.Size(138, 601);
            this.menuPanel.TabIndex = 24;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.pitem13, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.pitem5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.pitem12, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.pitem1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pitem6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.pitem4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.pitem9, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.pitem11, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.pitem2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pitem3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pitem8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.pitem7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.pitem10, 0, 9);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(138, 601);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pitem13
            // 
            this.pitem13.Controls.Add(this.piname13);
            this.pitem13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem13.Location = new System.Drawing.Point(3, 555);
            this.pitem13.Name = "pitem13";
            this.pitem13.Size = new System.Drawing.Size(132, 43);
            this.pitem13.TabIndex = 26;
            this.pitem13.Click += new System.EventHandler(this.MenuItem13_Click);
            this.pitem13.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem13.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname13
            // 
            this.piname13.AutoSize = true;
            this.piname13.BackColor = System.Drawing.Color.Transparent;
            this.piname13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname13.ForeColor = System.Drawing.Color.White;
            this.piname13.Location = new System.Drawing.Point(43, 14);
            this.piname13.Name = "piname13";
            this.piname13.Size = new System.Drawing.Size(42, 16);
            this.piname13.TabIndex = 3;
            this.piname13.Text = "About";
            this.piname13.Click += new System.EventHandler(this.MenuItem13_Click);
            this.piname13.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname13.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem5
            // 
            this.pitem5.Controls.Add(this.piname5);
            this.pitem5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem5.Location = new System.Drawing.Point(3, 187);
            this.pitem5.Name = "pitem5";
            this.pitem5.Size = new System.Drawing.Size(132, 40);
            this.pitem5.TabIndex = 26;
            this.pitem5.Click += new System.EventHandler(this.MenuItem5_Click);
            this.pitem5.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem5.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname5
            // 
            this.piname5.AutoSize = true;
            this.piname5.BackColor = System.Drawing.Color.Transparent;
            this.piname5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname5.ForeColor = System.Drawing.Color.White;
            this.piname5.Location = new System.Drawing.Point(26, 5);
            this.piname5.Name = "piname5";
            this.piname5.Size = new System.Drawing.Size(79, 32);
            this.piname5.TabIndex = 3;
            this.piname5.Text = "    Import\r\nLayer Image";
            this.piname5.Click += new System.EventHandler(this.MenuItem5_Click);
            this.piname5.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname5.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem12
            // 
            this.pitem12.Controls.Add(this.piname12);
            this.pitem12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem12.Location = new System.Drawing.Point(3, 509);
            this.pitem12.Name = "pitem12";
            this.pitem12.Size = new System.Drawing.Size(132, 40);
            this.pitem12.TabIndex = 25;
            this.pitem12.Click += new System.EventHandler(this.MenuItem12_Click);
            this.pitem12.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem12.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname12
            // 
            this.piname12.AutoSize = true;
            this.piname12.BackColor = System.Drawing.Color.Transparent;
            this.piname12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname12.ForeColor = System.Drawing.Color.White;
            this.piname12.Location = new System.Drawing.Point(30, 5);
            this.piname12.Name = "piname12";
            this.piname12.Size = new System.Drawing.Size(72, 32);
            this.piname12.TabIndex = 3;
            this.piname12.Text = "Check For \r\n  Updates";
            this.piname12.Click += new System.EventHandler(this.MenuItem12_Click);
            this.piname12.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname12.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem1
            // 
            this.pitem1.Controls.Add(this.piname1);
            this.pitem1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem1.Location = new System.Drawing.Point(3, 3);
            this.pitem1.Name = "pitem1";
            this.pitem1.Size = new System.Drawing.Size(132, 40);
            this.pitem1.TabIndex = 25;
            this.pitem1.Click += new System.EventHandler(this.MenuItem1_Click);
            this.pitem1.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem1.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname1
            // 
            this.piname1.AutoSize = true;
            this.piname1.BackColor = System.Drawing.Color.Transparent;
            this.piname1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname1.ForeColor = System.Drawing.Color.White;
            this.piname1.Location = new System.Drawing.Point(37, 5);
            this.piname1.Name = "piname1";
            this.piname1.Size = new System.Drawing.Size(55, 32);
            this.piname1.TabIndex = 3;
            this.piname1.Text = "   New \r\nSession";
            this.piname1.Click += new System.EventHandler(this.MenuItem1_Click);
            this.piname1.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname1.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem6
            // 
            this.pitem6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.pitem6.Controls.Add(this.piname6);
            this.pitem6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem6.Location = new System.Drawing.Point(3, 233);
            this.pitem6.Name = "pitem6";
            this.pitem6.Size = new System.Drawing.Size(132, 40);
            this.pitem6.TabIndex = 25;
            this.pitem6.Click += new System.EventHandler(this.MenuItem6_Click);
            this.pitem6.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem6.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname6
            // 
            this.piname6.AutoSize = true;
            this.piname6.BackColor = System.Drawing.Color.Transparent;
            this.piname6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.piname6.Location = new System.Drawing.Point(29, 5);
            this.piname6.Name = "piname6";
            this.piname6.Size = new System.Drawing.Size(72, 32);
            this.piname6.TabIndex = 3;
            this.piname6.Text = "   Disable \r\nBlack Bars\r\n";
            this.piname6.Click += new System.EventHandler(this.MenuItem6_Click);
            this.piname6.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname6.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem4
            // 
            this.pitem4.Controls.Add(this.piname4);
            this.pitem4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem4.Location = new System.Drawing.Point(3, 141);
            this.pitem4.Name = "pitem4";
            this.pitem4.Size = new System.Drawing.Size(132, 40);
            this.pitem4.TabIndex = 25;
            this.pitem4.Click += new System.EventHandler(this.MenuItem4_Click);
            this.pitem4.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem4.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname4
            // 
            this.piname4.AutoSize = true;
            this.piname4.BackColor = System.Drawing.Color.Transparent;
            this.piname4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname4.ForeColor = System.Drawing.Color.White;
            this.piname4.Location = new System.Drawing.Point(36, 5);
            this.piname4.Name = "piname4";
            this.piname4.Size = new System.Drawing.Size(59, 32);
            this.piname4.TabIndex = 3;
            this.piname4.Text = "  Import \r\nChatlogs";
            this.piname4.Click += new System.EventHandler(this.MenuItem4_Click);
            this.piname4.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname4.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem9
            // 
            this.pitem9.Controls.Add(this.piname9);
            this.pitem9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem9.Location = new System.Drawing.Point(3, 371);
            this.pitem9.Name = "pitem9";
            this.pitem9.Size = new System.Drawing.Size(132, 40);
            this.pitem9.TabIndex = 25;
            this.pitem9.Click += new System.EventHandler(this.MenuItem9_Click);
            this.pitem9.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem9.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname9
            // 
            this.piname9.AutoSize = true;
            this.piname9.BackColor = System.Drawing.Color.Transparent;
            this.piname9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname9.ForeColor = System.Drawing.Color.White;
            this.piname9.Location = new System.Drawing.Point(29, 5);
            this.piname9.Name = "piname9";
            this.piname9.Size = new System.Drawing.Size(71, 32);
            this.piname9.TabIndex = 3;
            this.piname9.Text = "   Enable \r\nLayer Drag";
            this.piname9.Click += new System.EventHandler(this.MenuItem9_Click);
            this.piname9.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname9.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem11
            // 
            this.pitem11.Controls.Add(this.piname11);
            this.pitem11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem11.Location = new System.Drawing.Point(3, 463);
            this.pitem11.Name = "pitem11";
            this.pitem11.Size = new System.Drawing.Size(132, 40);
            this.pitem11.TabIndex = 27;
            this.pitem11.Click += new System.EventHandler(this.MenuItem11_Click);
            this.pitem11.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem11.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname11
            // 
            this.piname11.AutoSize = true;
            this.piname11.BackColor = System.Drawing.Color.Transparent;
            this.piname11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname11.ForeColor = System.Drawing.Color.White;
            this.piname11.Location = new System.Drawing.Point(38, 5);
            this.piname11.Name = "piname11";
            this.piname11.Size = new System.Drawing.Size(54, 32);
            this.piname11.TabIndex = 3;
            this.piname11.Text = "Remove\r\n  Layer";
            this.piname11.Click += new System.EventHandler(this.MenuItem11_Click);
            this.piname11.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname11.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem2
            // 
            this.pitem2.Controls.Add(this.piname2);
            this.pitem2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem2.Location = new System.Drawing.Point(3, 49);
            this.pitem2.Name = "pitem2";
            this.pitem2.Size = new System.Drawing.Size(132, 40);
            this.pitem2.TabIndex = 25;
            this.pitem2.Click += new System.EventHandler(this.MenuItem2_Click);
            this.pitem2.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem2.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname2
            // 
            this.piname2.AutoSize = true;
            this.piname2.BackColor = System.Drawing.Color.Transparent;
            this.piname2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname2.ForeColor = System.Drawing.Color.White;
            this.piname2.Location = new System.Drawing.Point(31, 5);
            this.piname2.Name = "piname2";
            this.piname2.Size = new System.Drawing.Size(62, 32);
            this.piname2.TabIndex = 3;
            this.piname2.Text = " Save As\r\nNew JPG";
            this.piname2.Click += new System.EventHandler(this.MenuItem2_Click);
            this.piname2.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname2.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem3
            // 
            this.pitem3.Controls.Add(this.piname3);
            this.pitem3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem3.Location = new System.Drawing.Point(3, 95);
            this.pitem3.Name = "pitem3";
            this.pitem3.Size = new System.Drawing.Size(132, 40);
            this.pitem3.TabIndex = 25;
            this.pitem3.Click += new System.EventHandler(this.MenuItem3_Click);
            this.pitem3.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem3.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname3
            // 
            this.piname3.AutoSize = true;
            this.piname3.BackColor = System.Drawing.Color.Transparent;
            this.piname3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname3.ForeColor = System.Drawing.Color.White;
            this.piname3.Location = new System.Drawing.Point(27, 5);
            this.piname3.Name = "piname3";
            this.piname3.Size = new System.Drawing.Size(74, 32);
            this.piname3.TabIndex = 3;
            this.piname3.Text = "    Import \r\nScreenshot";
            this.piname3.Click += new System.EventHandler(this.MenuItem3_Click);
            this.piname3.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname3.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem8
            // 
            this.pitem8.Controls.Add(this.piname8);
            this.pitem8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem8.Location = new System.Drawing.Point(3, 325);
            this.pitem8.Name = "pitem8";
            this.pitem8.Size = new System.Drawing.Size(132, 40);
            this.pitem8.TabIndex = 25;
            this.pitem8.Click += new System.EventHandler(this.MenuItem8_Click);
            this.pitem8.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem8.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname8
            // 
            this.piname8.AutoSize = true;
            this.piname8.BackColor = System.Drawing.Color.Transparent;
            this.piname8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname8.ForeColor = System.Drawing.Color.White;
            this.piname8.Location = new System.Drawing.Point(27, 4);
            this.piname8.Name = "piname8";
            this.piname8.Size = new System.Drawing.Size(66, 32);
            this.piname8.TabIndex = 3;
            this.piname8.Text = "   Enable \r\nChat Drag\r\n";
            this.piname8.Click += new System.EventHandler(this.MenuItem8_Click);
            this.piname8.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname8.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem7
            // 
            this.pitem7.Controls.Add(this.piname7);
            this.pitem7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem7.Location = new System.Drawing.Point(3, 279);
            this.pitem7.Name = "pitem7";
            this.pitem7.Size = new System.Drawing.Size(132, 40);
            this.pitem7.TabIndex = 25;
            this.pitem7.Click += new System.EventHandler(this.MenuItem7_Click);
            this.pitem7.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem7.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname7
            // 
            this.piname7.AutoSize = true;
            this.piname7.BackColor = System.Drawing.Color.Transparent;
            this.piname7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname7.ForeColor = System.Drawing.Color.White;
            this.piname7.Location = new System.Drawing.Point(30, 5);
            this.piname7.Name = "piname7";
            this.piname7.Size = new System.Drawing.Size(74, 32);
            this.piname7.TabIndex = 3;
            this.piname7.Text = "   Enable \r\nImage Drag\r\n";
            this.piname7.Click += new System.EventHandler(this.MenuItem7_Click);
            this.piname7.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname7.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // pitem10
            // 
            this.pitem10.Controls.Add(this.piname10);
            this.pitem10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pitem10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pitem10.Location = new System.Drawing.Point(3, 417);
            this.pitem10.Name = "pitem10";
            this.pitem10.Size = new System.Drawing.Size(132, 40);
            this.pitem10.TabIndex = 26;
            this.pitem10.Click += new System.EventHandler(this.MenuItem10_Click);
            this.pitem10.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.pitem10.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // piname10
            // 
            this.piname10.AutoSize = true;
            this.piname10.BackColor = System.Drawing.Color.Transparent;
            this.piname10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.piname10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piname10.ForeColor = System.Drawing.Color.White;
            this.piname10.Location = new System.Drawing.Point(40, 4);
            this.piname10.Name = "piname10";
            this.piname10.Size = new System.Drawing.Size(50, 32);
            this.piname10.TabIndex = 3;
            this.piname10.Text = "Create \r\nLayer";
            this.piname10.Click += new System.EventHandler(this.MenuItem10_Click);
            this.piname10.MouseEnter += new System.EventHandler(this.MenuItems_MouseEnter);
            this.piname10.MouseLeave += new System.EventHandler(this.MenuItems_MouseLeave);
            // 
            // layerSelectionLabel
            // 
            this.layerSelectionLabel.AutoSize = true;
            this.layerSelectionLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.layerSelectionLabel.ForeColor = System.Drawing.Color.White;
            this.layerSelectionLabel.Location = new System.Drawing.Point(1134, 652);
            this.layerSelectionLabel.Name = "layerSelectionLabel";
            this.layerSelectionLabel.Size = new System.Drawing.Size(52, 13);
            this.layerSelectionLabel.TabIndex = 25;
            this.layerSelectionLabel.Text = "Set Layer";
            // 
            // layerSizeLabel
            // 
            this.layerSizeLabel.AutoSize = true;
            this.layerSizeLabel.BackColor = System.Drawing.Color.Transparent;
            this.layerSizeLabel.ForeColor = System.Drawing.Color.White;
            this.layerSizeLabel.Location = new System.Drawing.Point(65, 21);
            this.layerSizeLabel.Name = "layerSizeLabel";
            this.layerSizeLabel.Size = new System.Drawing.Size(56, 13);
            this.layerSizeLabel.TabIndex = 22;
            this.layerSizeLabel.Text = "Layer Size";
            // 
            // trackBarLayerPanel
            // 
            this.trackBarLayerPanel.Controls.Add(this.layerSizeLabel);
            this.trackBarLayerPanel.Controls.Add(this.trackBarLayerSize);
            this.trackBarLayerPanel.Location = new System.Drawing.Point(591, 644);
            this.trackBarLayerPanel.Name = "trackBarLayerPanel";
            this.trackBarLayerPanel.Size = new System.Drawing.Size(216, 35);
            this.trackBarLayerPanel.TabIndex = 26;
            // 
            // trackBarImagePanel
            // 
            this.trackBarImagePanel.Controls.Add(this.imageSizeLabel);
            this.trackBarImagePanel.Controls.Add(this.trackBarImageSize);
            this.trackBarImagePanel.Location = new System.Drawing.Point(7, 643);
            this.trackBarImagePanel.Name = "trackBarImagePanel";
            this.trackBarImagePanel.Size = new System.Drawing.Size(216, 35);
            this.trackBarImagePanel.TabIndex = 27;
            // 
            // appTitle
            // 
            this.appTitle.AutoSize = true;
            this.appTitle.Font = new System.Drawing.Font("Arial", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.appTitle.Location = new System.Drawing.Point(297, 4);
            this.appTitle.Name = "appTitle";
            this.appTitle.Size = new System.Drawing.Size(339, 36);
            this.appTitle.TabIndex = 3;
            this.appTitle.Text = "Screenshot Magician";
            // 
            // appendBtn
            // 
            this.appendBtn.AutoSize = true;
            this.appendBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.appendBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.appendBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appendBtn.ForeColor = System.Drawing.Color.White;
            this.appendBtn.Location = new System.Drawing.Point(816, 648);
            this.appendBtn.Name = "appendBtn";
            this.appendBtn.Size = new System.Drawing.Size(56, 16);
            this.appendBtn.TabIndex = 28;
            this.appendBtn.Text = "Append";
            this.appendBtn.Click += new System.EventHandler(this.AppendBtn_Click);
            this.appendBtn.MouseEnter += new System.EventHandler(this.AppendBtn_MouseEnter);
            this.appendBtn.MouseLeave += new System.EventHandler(this.AppendBtn_MouseLeave);
            // 
            // minBtnLabel
            // 
            this.minBtnLabel.AutoSize = true;
            this.minBtnLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minBtnLabel.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minBtnLabel.ForeColor = System.Drawing.Color.White;
            this.minBtnLabel.Location = new System.Drawing.Point(1215, 4);
            this.minBtnLabel.Name = "minBtnLabel";
            this.minBtnLabel.Size = new System.Drawing.Size(22, 24);
            this.minBtnLabel.TabIndex = 31;
            this.minBtnLabel.Text = "_";
            this.minBtnLabel.Click += new System.EventHandler(this.MinBtn_Click);
            this.minBtnLabel.MouseEnter += new System.EventHandler(this.MinBtn_MouseEnter);
            this.minBtnLabel.MouseLeave += new System.EventHandler(this.MinBtn_MouseLeave);
            // 
            // settingsBtnLabel
            // 
            this.settingsBtnLabel.AutoSize = true;
            this.settingsBtnLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.settingsBtnLabel.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsBtnLabel.ForeColor = System.Drawing.Color.White;
            this.settingsBtnLabel.Location = new System.Drawing.Point(1177, 4);
            this.settingsBtnLabel.Name = "settingsBtnLabel";
            this.settingsBtnLabel.Size = new System.Drawing.Size(32, 24);
            this.settingsBtnLabel.TabIndex = 32;
            this.settingsBtnLabel.Text = "⚙️";
            this.settingsBtnLabel.Click += new System.EventHandler(this.SettingsBtn_Click);
            this.settingsBtnLabel.MouseEnter += new System.EventHandler(this.SettingsBtn_MouseEnter);
            this.settingsBtnLabel.MouseLeave += new System.EventHandler(this.SettingsBtn_MouseLeave);
            // 
            // settingsPanel
            // 
            this.settingsPanel.Controls.Add(this.groupBox2);
            this.settingsPanel.Controls.Add(this.groupBox3);
            this.settingsPanel.Controls.Add(this.SettingsCloseBtn);
            this.settingsPanel.Controls.Add(this.settingsLabel);
            this.settingsPanel.Controls.Add(this.groupBox4);
            this.settingsPanel.Controls.Add(this.saveCharNameBtn);
            this.settingsPanel.Controls.Add(this.charLabel);
            this.settingsPanel.Controls.Add(this.charNameBox);
            this.settingsPanel.Controls.Add(this.numericUpDown1);
            this.settingsPanel.Controls.Add(this.groupBox1);
            this.settingsPanel.Controls.Add(this.editorToggleButton1);
            this.settingsPanel.Controls.Add(this.addCharLabel);
            this.settingsPanel.Enabled = false;
            this.settingsPanel.Location = new System.Drawing.Point(182, 137);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(867, 0);
            this.settingsPanel.TabIndex = 33;
            this.settingsPanel.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox14);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textBox13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.screenshotsBrowseBtn);
            this.groupBox2.Controls.Add(this.textBox12);
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.groupBox2.Location = new System.Drawing.Point(302, 117);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(198, 282);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Directory Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(27, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 24);
            this.label10.TabIndex = 44;
            this.label10.Text = "Rage MP Folder";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(9, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 16);
            this.label11.TabIndex = 43;
            this.label11.Text = "Browse";
            this.label11.Click += new System.EventHandler(this.RAGEBrowseBtn_Click);
            this.label11.MouseEnter += new System.EventHandler(this.RAGEBrowseBtn_MouseEnter);
            this.label11.MouseLeave += new System.EventHandler(this.RAGEBrowseBtn_MouseLeave);
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox15.ForeColor = System.Drawing.Color.White;
            this.textBox15.Location = new System.Drawing.Point(74, 47);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(116, 20);
            this.textBox15.TabIndex = 42;
            this.textBox15.Text = "C:/RAGEMP/";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(29, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 24);
            this.label7.TabIndex = 41;
            this.label7.Text = "Backups Folder";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(9, 257);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 16);
            this.label9.TabIndex = 40;
            this.label9.Text = "Browse";
            this.label9.Click += new System.EventHandler(this.BackupsBrowseBtn_Click);
            this.label9.MouseEnter += new System.EventHandler(this.label9_MouseEnter);
            this.label9.MouseLeave += new System.EventHandler(this.label9_MouseLeave);
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox14.ForeColor = System.Drawing.Color.White;
            this.textBox14.Location = new System.Drawing.Point(74, 257);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(116, 20);
            this.textBox14.TabIndex = 39;
            this.textBox14.Text = "/Backups/";
            this.textBox14.TextChanged += new System.EventHandler(this.TextBox14_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(28, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 24);
            this.label5.TabIndex = 38;
            this.label5.Text = "Chatlogs Folder";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(9, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 37;
            this.label6.Text = "Browse";
            this.label6.Click += new System.EventHandler(this.ChatlogsBrowseBtn_Click);
            this.label6.MouseEnter += new System.EventHandler(this.label6_MouseEnter);
            this.label6.MouseLeave += new System.EventHandler(this.label6_MouseLeave);
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox13.ForeColor = System.Drawing.Color.White;
            this.textBox13.Location = new System.Drawing.Point(74, 187);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(116, 20);
            this.textBox13.TabIndex = 36;
            this.textBox13.Text = "/Chatlogs/";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(13, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 24);
            this.label4.TabIndex = 35;
            this.label4.Text = "Screenshots Folder";
            // 
            // screenshotsBrowseBtn
            // 
            this.screenshotsBrowseBtn.AutoSize = true;
            this.screenshotsBrowseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.screenshotsBrowseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.screenshotsBrowseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.screenshotsBrowseBtn.ForeColor = System.Drawing.Color.White;
            this.screenshotsBrowseBtn.Location = new System.Drawing.Point(8, 117);
            this.screenshotsBrowseBtn.Name = "screenshotsBrowseBtn";
            this.screenshotsBrowseBtn.Size = new System.Drawing.Size(53, 16);
            this.screenshotsBrowseBtn.TabIndex = 34;
            this.screenshotsBrowseBtn.Text = "Browse";
            this.screenshotsBrowseBtn.Click += new System.EventHandler(this.ScreenshotsBrowseBtn_Click);
            this.screenshotsBrowseBtn.MouseEnter += new System.EventHandler(this.ScreenshotsBrowseBtn_MouseEnter);
            this.screenshotsBrowseBtn.MouseLeave += new System.EventHandler(this.ScreenshotsBrowseBtn_MouseLeave);
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox12.ForeColor = System.Drawing.Color.White;
            this.textBox12.Location = new System.Drawing.Point(73, 117);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(116, 20);
            this.textBox12.TabIndex = 30;
            this.textBox12.Text = "/Screenshots/";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.groupBox3.Controls.Add(this.numericUpDown2);
            this.groupBox3.Controls.Add(this.checkBox11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.checkBox14);
            this.groupBox3.Controls.Add(this.checkBox13);
            this.groupBox3.Controls.Add(this.checkBox12);
            this.groupBox3.Controls.Add(this.editorToggleButton2);
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.groupBox3.Location = new System.Drawing.Point(506, 117);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(355, 146);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Parser Settings";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.numericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numericUpDown2.Enabled = false;
            this.numericUpDown2.ForeColor = System.Drawing.Color.White;
            this.numericUpDown2.Location = new System.Drawing.Point(215, 54);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(37, 20);
            this.numericUpDown2.TabIndex = 46;
            this.numericUpDown2.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.NumericUpDown2_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(55, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(249, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "Parse and backup when game closes automatically";
            // 
            // SettingsCloseBtn
            // 
            this.SettingsCloseBtn.AutoSize = true;
            this.SettingsCloseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SettingsCloseBtn.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsCloseBtn.ForeColor = System.Drawing.Color.White;
            this.SettingsCloseBtn.Location = new System.Drawing.Point(840, 3);
            this.SettingsCloseBtn.Name = "SettingsCloseBtn";
            this.SettingsCloseBtn.Size = new System.Drawing.Size(24, 24);
            this.SettingsCloseBtn.TabIndex = 35;
            this.SettingsCloseBtn.Text = "X";
            this.SettingsCloseBtn.Click += new System.EventHandler(this.SettingsCloseBtn_Click);
            this.SettingsCloseBtn.MouseEnter += new System.EventHandler(this.SettingsCloseBtn_MouseEnter);
            this.SettingsCloseBtn.MouseLeave += new System.EventHandler(this.SettingsCloseBtn_MouseLeave);
            // 
            // settingsLabel
            // 
            this.settingsLabel.AutoSize = true;
            this.settingsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsLabel.ForeColor = System.Drawing.Color.White;
            this.settingsLabel.Location = new System.Drawing.Point(4, 3);
            this.settingsLabel.Name = "settingsLabel";
            this.settingsLabel.Size = new System.Drawing.Size(113, 31);
            this.settingsLabel.TabIndex = 52;
            this.settingsLabel.Text = "Settings";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox16);
            this.groupBox4.Controls.Add(this.checkBox25);
            this.groupBox4.Controls.Add(this.checkBox24);
            this.groupBox4.Controls.Add(this.checkBox23);
            this.groupBox4.Controls.Add(this.checkBox22);
            this.groupBox4.Controls.Add(this.checkBox20);
            this.groupBox4.Controls.Add(this.checkBox21);
            this.groupBox4.Controls.Add(this.checkBox19);
            this.groupBox4.Controls.Add(this.checkBox18);
            this.groupBox4.Controls.Add(this.checkBox17);
            this.groupBox4.Controls.Add(this.checkBox16);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.groupBox4.Location = new System.Drawing.Point(507, 265);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(355, 135);
            this.groupBox4.TabIndex = 51;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parser Filter";
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.ForeColor = System.Drawing.Color.Black;
            this.textBox16.Location = new System.Drawing.Point(124, 40);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox16.Size = new System.Drawing.Size(223, 77);
            this.textBox16.TabIndex = 61;
            this.textBox16.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox25.ForeColor = System.Drawing.Color.White;
            this.checkBox25.Location = new System.Drawing.Point(270, 17);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(77, 17);
            this.checkBox25.TabIndex = 60;
            this.checkBox25.Text = "Word Filter";
            this.checkBox25.UseVisualStyleBackColor = true;
            this.checkBox25.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox24.ForeColor = System.Drawing.Color.White;
            this.checkBox24.Location = new System.Drawing.Point(8, 100);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(121, 17);
            this.checkBox24.TabIndex = 59;
            this.checkBox24.Text = "Remove timestamps";
            this.checkBox24.UseVisualStyleBackColor = true;
            this.checkBox24.CheckedChanged += new System.EventHandler(this.checkBox24_CheckedChanged);
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Checked = true;
            this.checkBox23.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox23.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox23.ForeColor = System.Drawing.Color.White;
            this.checkBox23.Location = new System.Drawing.Point(66, 80);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(52, 17);
            this.checkBox23.TabIndex = 58;
            this.checkBox23.Text = "Other";
            this.checkBox23.UseVisualStyleBackColor = true;
            this.checkBox23.CheckedChanged += new System.EventHandler(this.checkBox23_CheckedChanged);
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Checked = true;
            this.checkBox22.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox22.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox22.ForeColor = System.Drawing.Color.White;
            this.checkBox22.Location = new System.Drawing.Point(8, 80);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(44, 17);
            this.checkBox22.TabIndex = 57;
            this.checkBox22.Text = "Ads";
            this.checkBox22.UseVisualStyleBackColor = true;
            this.checkBox22.CheckedChanged += new System.EventHandler(this.checkBox22_CheckedChanged);
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Checked = true;
            this.checkBox20.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox20.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox20.ForeColor = System.Drawing.Color.White;
            this.checkBox20.Location = new System.Drawing.Point(66, 60);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(42, 17);
            this.checkBox20.TabIndex = 56;
            this.checkBox20.Text = "PM";
            this.checkBox20.UseVisualStyleBackColor = true;
            this.checkBox20.CheckedChanged += new System.EventHandler(this.checkBox20_CheckedChanged);
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Checked = true;
            this.checkBox21.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox21.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox21.ForeColor = System.Drawing.Color.White;
            this.checkBox21.Location = new System.Drawing.Point(8, 60);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(54, 17);
            this.checkBox21.TabIndex = 55;
            this.checkBox21.Text = "Radio";
            this.checkBox21.UseVisualStyleBackColor = true;
            this.checkBox21.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Checked = true;
            this.checkBox19.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox19.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox19.ForeColor = System.Drawing.Color.White;
            this.checkBox19.Location = new System.Drawing.Point(66, 40);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(56, 17);
            this.checkBox19.TabIndex = 54;
            this.checkBox19.Text = "Action";
            this.checkBox19.UseVisualStyleBackColor = true;
            this.checkBox19.CheckedChanged += new System.EventHandler(this.checkBox19_CheckedChanged);
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Checked = true;
            this.checkBox18.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox18.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox18.ForeColor = System.Drawing.Color.White;
            this.checkBox18.Location = new System.Drawing.Point(8, 40);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(56, 17);
            this.checkBox18.TabIndex = 53;
            this.checkBox18.Text = "Emote";
            this.checkBox18.UseVisualStyleBackColor = true;
            this.checkBox18.CheckedChanged += new System.EventHandler(this.checkBox18_CheckedChanged);
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Checked = true;
            this.checkBox17.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox17.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox17.ForeColor = System.Drawing.Color.White;
            this.checkBox17.Location = new System.Drawing.Point(66, 20);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(49, 17);
            this.checkBox17.TabIndex = 52;
            this.checkBox17.Text = "OOC";
            this.checkBox17.UseVisualStyleBackColor = true;
            this.checkBox17.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Checked = true;
            this.checkBox16.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox16.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox16.ForeColor = System.Drawing.Color.White;
            this.checkBox16.Location = new System.Drawing.Point(8, 20);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(52, 17);
            this.checkBox16.TabIndex = 51;
            this.checkBox16.Text = "Local";
            this.checkBox16.UseVisualStyleBackColor = true;
            this.checkBox16.CheckedChanged += new System.EventHandler(this.checkBox16_CheckedChanged);
            // 
            // saveCharNameBtn
            // 
            this.saveCharNameBtn.AutoSize = true;
            this.saveCharNameBtn.ForeColor = System.Drawing.Color.White;
            this.saveCharNameBtn.Location = new System.Drawing.Point(228, 65);
            this.saveCharNameBtn.Name = "saveCharNameBtn";
            this.saveCharNameBtn.Size = new System.Drawing.Size(139, 17);
            this.saveCharNameBtn.TabIndex = 46;
            this.saveCharNameBtn.Text = "Save on program restart";
            this.saveCharNameBtn.UseVisualStyleBackColor = true;
            this.saveCharNameBtn.CheckedChanged += new System.EventHandler(this.SaveCharNameBtn_CheckedChanged);
            // 
            // charLabel
            // 
            this.charLabel.AutoSize = true;
            this.charLabel.ForeColor = System.Drawing.Color.White;
            this.charLabel.Location = new System.Drawing.Point(24, 66);
            this.charLabel.Name = "charLabel";
            this.charLabel.Size = new System.Drawing.Size(81, 13);
            this.charLabel.TabIndex = 3;
            this.charLabel.Text = "Your Character:";
            // 
            // charNameBox
            // 
            this.charNameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.charNameBox.ForeColor = System.Drawing.Color.White;
            this.charNameBox.Location = new System.Drawing.Point(106, 63);
            this.charNameBox.Name = "charNameBox";
            this.charNameBox.Size = new System.Drawing.Size(116, 20);
            this.charNameBox.TabIndex = 30;
            this.charNameBox.Text = "Character Name";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numericUpDown1.Enabled = false;
            this.numericUpDown1.ForeColor = System.Drawing.Color.White;
            this.numericUpDown1.Location = new System.Drawing.Point(259, 100);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(37, 20);
            this.numericUpDown1.TabIndex = 3;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.NumericUpDown1_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox10);
            this.groupBox1.Controls.Add(this.comboBox10);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.checkBox9);
            this.groupBox1.Controls.Add(this.comboBox9);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.checkBox8);
            this.groupBox1.Controls.Add(this.comboBox8);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.comboBox7);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.comboBox6);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.comboBox5);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Enabled = false;
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.groupBox1.Location = new System.Drawing.Point(5, 117);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(291, 282);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Characters";
            // 
            // comboBox10
            // 
            this.comboBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox10.Enabled = false;
            this.comboBox10.ForeColor = System.Drawing.Color.White;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox10.Location = new System.Drawing.Point(129, 246);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(69, 21);
            this.comboBox10.TabIndex = 28;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox11.Enabled = false;
            this.textBox11.ForeColor = System.Drawing.Color.White;
            this.textBox11.Location = new System.Drawing.Point(7, 246);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(116, 20);
            this.textBox11.TabIndex = 27;
            this.textBox11.Text = "Character Name";
            // 
            // comboBox9
            // 
            this.comboBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox9.Enabled = false;
            this.comboBox9.ForeColor = System.Drawing.Color.White;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox9.Location = new System.Drawing.Point(129, 221);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(69, 21);
            this.comboBox9.TabIndex = 25;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox10.Enabled = false;
            this.textBox10.ForeColor = System.Drawing.Color.White;
            this.textBox10.Location = new System.Drawing.Point(7, 221);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(116, 20);
            this.textBox10.TabIndex = 24;
            this.textBox10.Text = "Character Name";
            // 
            // comboBox8
            // 
            this.comboBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox8.Enabled = false;
            this.comboBox8.ForeColor = System.Drawing.Color.White;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox8.Location = new System.Drawing.Point(129, 196);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(69, 21);
            this.comboBox8.TabIndex = 22;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox9.Enabled = false;
            this.textBox9.ForeColor = System.Drawing.Color.White;
            this.textBox9.Location = new System.Drawing.Point(7, 196);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(116, 20);
            this.textBox9.TabIndex = 21;
            this.textBox9.Text = "Character Name";
            // 
            // comboBox7
            // 
            this.comboBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox7.Enabled = false;
            this.comboBox7.ForeColor = System.Drawing.Color.White;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox7.Location = new System.Drawing.Point(129, 171);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(69, 21);
            this.comboBox7.TabIndex = 19;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox8.Enabled = false;
            this.textBox8.ForeColor = System.Drawing.Color.White;
            this.textBox8.Location = new System.Drawing.Point(7, 171);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(116, 20);
            this.textBox8.TabIndex = 18;
            this.textBox8.Text = "Character Name";
            // 
            // comboBox6
            // 
            this.comboBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox6.Enabled = false;
            this.comboBox6.ForeColor = System.Drawing.Color.White;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox6.Location = new System.Drawing.Point(129, 146);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(69, 21);
            this.comboBox6.TabIndex = 16;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox7.Enabled = false;
            this.textBox7.ForeColor = System.Drawing.Color.White;
            this.textBox7.Location = new System.Drawing.Point(7, 146);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(116, 20);
            this.textBox7.TabIndex = 15;
            this.textBox7.Text = "Character Name";
            // 
            // comboBox5
            // 
            this.comboBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox5.Enabled = false;
            this.comboBox5.ForeColor = System.Drawing.Color.White;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox5.Location = new System.Drawing.Point(129, 121);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(69, 21);
            this.comboBox5.TabIndex = 13;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox6.Enabled = false;
            this.textBox6.ForeColor = System.Drawing.Color.White;
            this.textBox6.Location = new System.Drawing.Point(7, 121);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(116, 20);
            this.textBox6.TabIndex = 12;
            this.textBox6.Text = "Character Name";
            // 
            // comboBox4
            // 
            this.comboBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox4.Enabled = false;
            this.comboBox4.ForeColor = System.Drawing.Color.White;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox4.Location = new System.Drawing.Point(129, 96);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(69, 21);
            this.comboBox4.TabIndex = 10;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox4.Enabled = false;
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(7, 71);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(116, 20);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "Character Name";
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox3.Enabled = false;
            this.comboBox3.ForeColor = System.Drawing.Color.White;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox3.Location = new System.Drawing.Point(129, 71);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(69, 21);
            this.comboBox3.TabIndex = 7;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox5.Enabled = false;
            this.textBox5.ForeColor = System.Drawing.Color.White;
            this.textBox5.Location = new System.Drawing.Point(7, 96);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(116, 20);
            this.textBox5.TabIndex = 6;
            this.textBox5.Text = "Character Name";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox2.Enabled = false;
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox2.Location = new System.Drawing.Point(129, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(69, 21);
            this.comboBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox3.Enabled = false;
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(7, 46);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(116, 20);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "Character Name";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.comboBox1.ForeColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Close",
            "Far"});
            this.comboBox1.Location = new System.Drawing.Point(129, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(69, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(7, 21);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(116, 20);
            this.textBox2.TabIndex = 0;
            this.textBox2.Text = "Character Name";
            // 
            // addCharLabel
            // 
            this.addCharLabel.AutoSize = true;
            this.addCharLabel.ForeColor = System.Drawing.Color.White;
            this.addCharLabel.Location = new System.Drawing.Point(69, 93);
            this.addCharLabel.Name = "addCharLabel";
            this.addCharLabel.Size = new System.Drawing.Size(141, 13);
            this.addCharLabel.TabIndex = 0;
            this.addCharLabel.Text = "Add characters to the scene";
            // 
            // settingsPanelBorder
            // 
            this.settingsPanelBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.settingsPanelBorder.Enabled = false;
            this.settingsPanelBorder.Location = new System.Drawing.Point(180, 135);
            this.settingsPanelBorder.Name = "settingsPanelBorder";
            this.settingsPanelBorder.Size = new System.Drawing.Size(871, 0);
            this.settingsPanelBorder.TabIndex = 34;
            this.settingsPanelBorder.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(881, 648);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 16);
            this.label1.TabIndex = 35;
            this.label1.Text = "Parser";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            this.label1.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.label1.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(903, 432);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(262, 0);
            this.panel1.TabIndex = 36;
            this.panel1.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(166, 183);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 16);
            this.label13.TabIndex = 39;
            this.label13.Text = "Save Chatlog";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            this.label13.MouseEnter += new System.EventHandler(this.label13_MouseEnter);
            this.label13.MouseLeave += new System.EventHandler(this.label13_MouseLeave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(6, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 16);
            this.label8.TabIndex = 38;
            this.label8.Text = "Parse\r\n";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            this.label8.MouseEnter += new System.EventHandler(this.label8_MouseEnter);
            this.label8.MouseLeave += new System.EventHandler(this.label8_MouseLeave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(61, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 37;
            this.label3.Text = "Parse to Editor\r\n";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            this.label3.MouseEnter += new System.EventHandler(this.label3_MouseEnter);
            this.label3.MouseLeave += new System.EventHandler(this.label3_MouseLeave);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(255, 176);
            this.textBox1.TabIndex = 37;
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.trackBar1.Location = new System.Drawing.Point(297, 644);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(226, 45);
            this.trackBar1.TabIndex = 23;
            this.trackBar1.TabStop = false;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Value = 100;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(375, 665);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Layer Opacity";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.label14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(935, 648);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 16);
            this.label14.TabIndex = 37;
            this.label14.Text = "Open Text Editor";
            this.label14.Visible = false;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Enabled = false;
            this.checkBox11.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox11.ForeColor = System.Drawing.Color.White;
            this.checkBox11.Location = new System.Drawing.Point(8, 55);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(343, 17);
            this.checkBox11.TabIndex = 51;
            this.checkBox11.Text = "Auto backup while the game is running                (every 10 minutes)";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.CheckBox11_CheckedChanged);
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Enabled = false;
            this.checkBox14.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox14.ForeColor = System.Drawing.Color.White;
            this.checkBox14.Location = new System.Drawing.Point(8, 124);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(319, 17);
            this.checkBox14.TabIndex = 49;
            this.checkBox14.Text = "Warn when the same backup has been saved 2 or more times";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Enabled = false;
            this.checkBox13.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox13.ForeColor = System.Drawing.Color.White;
            this.checkBox13.Location = new System.Drawing.Point(8, 101);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(340, 17);
            this.checkBox13.TabIndex = 48;
            this.checkBox13.Text = "Suppress all of the successful backup notifications from happening";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Enabled = false;
            this.checkBox12.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox12.ForeColor = System.Drawing.Color.White;
            this.checkBox12.Location = new System.Drawing.Point(8, 78);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(342, 17);
            this.checkBox12.TabIndex = 47;
            this.checkBox12.Text = "Remove all the timestamps from the backup chat logs automatically";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // editorToggleButton2
            // 
            this.editorToggleButton2.AutoSize = true;
            this.editorToggleButton2.Location = new System.Drawing.Point(8, 22);
            this.editorToggleButton2.MinimumSize = new System.Drawing.Size(45, 22);
            this.editorToggleButton2.Name = "editorToggleButton2";
            this.editorToggleButton2.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.editorToggleButton2.OffToggleColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.editorToggleButton2.OnBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(65)))), ((int)(((byte)(88)))));
            this.editorToggleButton2.OnToggleColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.editorToggleButton2.Size = new System.Drawing.Size(45, 22);
            this.editorToggleButton2.TabIndex = 46;
            this.editorToggleButton2.UseVisualStyleBackColor = true;
            this.editorToggleButton2.CheckedChanged += new System.EventHandler(this.EditorToggleButton2_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Enabled = false;
            this.checkBox10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox10.ForeColor = System.Drawing.Color.White;
            this.checkBox10.Location = new System.Drawing.Point(204, 249);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(79, 17);
            this.checkBox10.TabIndex = 29;
            this.checkBox10.Text = "Cellphone?";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Enabled = false;
            this.checkBox9.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox9.ForeColor = System.Drawing.Color.White;
            this.checkBox9.Location = new System.Drawing.Point(204, 224);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(79, 17);
            this.checkBox9.TabIndex = 26;
            this.checkBox9.Text = "Cellphone?";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Enabled = false;
            this.checkBox8.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox8.ForeColor = System.Drawing.Color.White;
            this.checkBox8.Location = new System.Drawing.Point(204, 199);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(79, 17);
            this.checkBox8.TabIndex = 23;
            this.checkBox8.Text = "Cellphone?";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Enabled = false;
            this.checkBox7.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox7.ForeColor = System.Drawing.Color.White;
            this.checkBox7.Location = new System.Drawing.Point(204, 174);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(79, 17);
            this.checkBox7.TabIndex = 20;
            this.checkBox7.Text = "Cellphone?";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Enabled = false;
            this.checkBox6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox6.ForeColor = System.Drawing.Color.White;
            this.checkBox6.Location = new System.Drawing.Point(204, 149);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(79, 17);
            this.checkBox6.TabIndex = 17;
            this.checkBox6.Text = "Cellphone?";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Enabled = false;
            this.checkBox5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox5.ForeColor = System.Drawing.Color.White;
            this.checkBox5.Location = new System.Drawing.Point(204, 124);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(79, 17);
            this.checkBox5.TabIndex = 14;
            this.checkBox5.Text = "Cellphone?";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Enabled = false;
            this.checkBox4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox4.ForeColor = System.Drawing.Color.White;
            this.checkBox4.Location = new System.Drawing.Point(204, 99);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(79, 17);
            this.checkBox4.TabIndex = 11;
            this.checkBox4.Text = "Cellphone?";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox3.ForeColor = System.Drawing.Color.White;
            this.checkBox3.Location = new System.Drawing.Point(204, 74);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(79, 17);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "Cellphone?";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox2.ForeColor = System.Drawing.Color.White;
            this.checkBox2.Location = new System.Drawing.Point(204, 49);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(79, 17);
            this.checkBox2.TabIndex = 5;
            this.checkBox2.Text = "Cellphone?";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.checkBox1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(204, 24);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(79, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Cellphone?";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // editorToggleButton1
            // 
            this.editorToggleButton1.AutoSize = true;
            this.editorToggleButton1.Location = new System.Drawing.Point(19, 89);
            this.editorToggleButton1.MinimumSize = new System.Drawing.Size(45, 22);
            this.editorToggleButton1.Name = "editorToggleButton1";
            this.editorToggleButton1.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.editorToggleButton1.OffToggleColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.editorToggleButton1.OnBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(65)))), ((int)(((byte)(88)))));
            this.editorToggleButton1.OnToggleColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.editorToggleButton1.Size = new System.Drawing.Size(45, 22);
            this.editorToggleButton1.TabIndex = 1;
            this.editorToggleButton1.UseVisualStyleBackColor = true;
            this.editorToggleButton1.CheckedChanged += new System.EventHandler(this.EditorToggleButton1_CheckedChanged);
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1270, 680);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.settingsPanel);
            this.Controls.Add(this.settingsPanelBorder);
            this.Controls.Add(this.settingsBtnLabel);
            this.Controls.Add(this.minBtnLabel);
            this.Controls.Add(this.appendBtn);
            this.Controls.Add(this.appTitle);
            this.Controls.Add(this.trackBarImagePanel);
            this.Controls.Add(this.menuBtnLabel);
            this.Controls.Add(this.trackBarLayerPanel);
            this.Controls.Add(this.quitBtnLabel);
            this.Controls.Add(this.layerSelectionLabel);
            this.Controls.Add(this.menuBtnSymbol);
            this.Controls.Add(this.menuPanel);
            this.Controls.Add(this.comboBoxLayers);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtChatLog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Screenshot Magician v1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarImageSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarLayerSize)).EndInit();
            this.menuPanel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pitem13.ResumeLayout(false);
            this.pitem13.PerformLayout();
            this.pitem5.ResumeLayout(false);
            this.pitem5.PerformLayout();
            this.pitem12.ResumeLayout(false);
            this.pitem12.PerformLayout();
            this.pitem1.ResumeLayout(false);
            this.pitem1.PerformLayout();
            this.pitem6.ResumeLayout(false);
            this.pitem6.PerformLayout();
            this.pitem4.ResumeLayout(false);
            this.pitem4.PerformLayout();
            this.pitem9.ResumeLayout(false);
            this.pitem9.PerformLayout();
            this.pitem11.ResumeLayout(false);
            this.pitem11.PerformLayout();
            this.pitem2.ResumeLayout(false);
            this.pitem2.PerformLayout();
            this.pitem3.ResumeLayout(false);
            this.pitem3.PerformLayout();
            this.pitem8.ResumeLayout(false);
            this.pitem8.PerformLayout();
            this.pitem7.ResumeLayout(false);
            this.pitem7.PerformLayout();
            this.pitem10.ResumeLayout(false);
            this.pitem10.PerformLayout();
            this.trackBarLayerPanel.ResumeLayout(false);
            this.trackBarLayerPanel.PerformLayout();
            this.trackBarImagePanel.ResumeLayout(false);
            this.trackBarImagePanel.PerformLayout();
            this.settingsPanel.ResumeLayout(false);
            this.settingsPanel.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        //layer system
        private ComboBox comboBoxLayers;
        private int currentLayerIndex;
        private TrackBar trackBarLayerSize;
        private Label quitBtnLabel;
        private Label menuBtnSymbol;
        private Panel menuPanel;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel pitem2;
        private Panel pitem8;
        private Panel pitem7;
        private Panel pitem9;
        private Panel pitem6;
        private Panel pitem5;
        private Panel pitem4;
        private Panel pitem3;
        private Panel pitem1;
        private Label menuBtnLabel;
        private Label piname3;
        private Label piname1;
        private Label piname12;
        private Label piname2;
        private Label piname8;
        private Label piname7;
        private Label piname9;
        private Label piname6;
        private Label piname4;
        private Panel pitem12;
        private Label piname5;
        private Label layerSelectionLabel;
        private Panel pitem10;
        private Label piname10;
        private Panel pitem11;
        private Label piname11;
        private Panel trackBarLayerPanel;
        private Panel trackBarImagePanel;
        private Label appTitle;
        private Label appendBtn;
        private Label minBtnLabel;
        private Label settingsBtnLabel;
        private Panel settingsPanel;
        private Label addCharLabel;
        private GroupBox groupBox1;
        private ComboBox comboBox1;
        private TextBox textBox2;
        private ComboBox comboBox4;
        private TextBox textBox4;
        private ComboBox comboBox3;
        private TextBox textBox5;
        private ComboBox comboBox2;
        private TextBox textBox3;
        private ComboBox comboBox8;
        private TextBox textBox9;
        private ComboBox comboBox7;
        private TextBox textBox8;
        private ComboBox comboBox6;
        private TextBox textBox7;
        private ComboBox comboBox5;
        private TextBox textBox6;
        private ComboBox comboBox10;
        private TextBox textBox11;
        private ComboBox comboBox9;
        private TextBox textBox10;
        private TextBox charNameBox;
        private Label charLabel;
        private NumericUpDown numericUpDown1;
        private Label layerSizeLabel;
        private PictureBox pictureBox1;
        private TrackBar trackBarImageSize;
        private Label imageSizeLabel;
        private TextBox txtChatLog;


        #endregion

        private SS_EDITOR.CustomControl.EditorToggleButton editorToggleButton1;
        private GroupBox groupBox2;
        private Label label10;
        private Label label11;
        private TextBox textBox15;
        private Label label7;
        private Label label9;
        private TextBox textBox14;
        private Label label5;
        private Label label6;
        private TextBox textBox13;
        private Label label4;
        private Label screenshotsBrowseBtn;
        private TextBox textBox12;
        private GroupBox groupBox3;
        private SS_EDITOR.CustomControl.EditorToggleButton editorToggleButton2;
        private Label label12;
        private NumericUpDown numericUpDown2;
        private CheckBox saveCharNameBtn;
        private GroupBox groupBox4;
        private CheckBox checkBox23;
        private CheckBox checkBox22;
        private CheckBox checkBox20;
        private CheckBox checkBox21;
        private CheckBox checkBox19;
        private CheckBox checkBox18;
        private CheckBox checkBox17;
        private CheckBox checkBox16;
        private TextBox textBox16;
        private CheckBox checkBox25;
        private CheckBox checkBox24;
        private Label settingsLabel;
        private Panel pitem13;
        private Label piname13;
        private Panel settingsPanelBorder;
        private Label SettingsCloseBtn;
        //private CheckBox checkBox11;
        private CustomControls.EditorCheckBox checkBox11;
        private CustomControls.EditorCheckBox checkBox12;
        private CustomControls.EditorCheckBox checkBox13;
        private CustomControls.EditorCheckBox checkBox14;
        private CustomControls.EditorCheckBox checkBox10;
        private CustomControls.EditorCheckBox checkBox9;
        private CustomControls.EditorCheckBox checkBox8;
        private CustomControls.EditorCheckBox checkBox7;
        private CustomControls.EditorCheckBox checkBox6;
        private CustomControls.EditorCheckBox checkBox5;
        private CustomControls.EditorCheckBox checkBox4;
        private CustomControls.EditorCheckBox checkBox3;
        private CustomControls.EditorCheckBox checkBox2;
        private CustomControls.EditorCheckBox checkBox1;
        private Label label1;
        private Panel panel1;
        private Label label13;
        private Label label8;
        private Label label3;
        private TextBox textBox1;
        private TrackBar trackBar1;
        private Label label2;
        private Label label14;
    }
}

