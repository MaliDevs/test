﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenshotMagician
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //this.BackColor = Color.FromArgb(1, 1, 1);
            //this.TransparencyKey = Color.FromArgb(1, 1, 1);
            this.Shown += Form1_Shown;

            scrollBarV1.Value = customPanel7.VerticalScroll.Value;
            scrollBarV1.Minimum = customPanel7.VerticalScroll.Minimum;
            scrollBarV1.Maximum = customPanel7.VerticalScroll.Maximum;
            scrollBarV1.Scroll += scrollBarV1_Scroll;
            scrollBarH1.Value = customPanel7.HorizontalScroll.Value;
            scrollBarH1.Minimum = customPanel7.HorizontalScroll.Minimum;
            scrollBarH1.Maximum = customPanel7.HorizontalScroll.Maximum;
            scrollBarH1.Scroll += scrollBarH1_Scroll;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            customPanel7.AutoScroll = true;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            //form2.Show(); // Show Form2
            //this.Hide(); // Hide Form1
        }

        private void button8_MouseEnter(object sender, EventArgs e)
        {
            button8.BackgroundImage = global::ScreenshotMagician.Properties.Resources.Close_Button_Bg;
            button8.BackColor = Color.Red;
        }

        private void button8_MouseLeave(object sender, EventArgs e)
        {
            button8.BackgroundImage = null;
            button8.BackColor = Color.Transparent;
        }

        bool button1Clicked = false;
        bool button2Clicked = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if (!button1Clicked)
            {
                button1.BackColor = Color.FromArgb(93, 93, 93);
                panel2.BackColor = Color.FromArgb(40, 40, 40);
                panel3.BackColor = Color.FromArgb(40, 40, 40);
                panel4.BackColor = Color.FromArgb(40, 40, 40);
                panel5.BackColor = Color.FromArgb(40, 40, 40);
                customPanel9.Visible = true;
                button1Clicked = true;
            } else {
                button1.BackColor = Color.Transparent;
                customPanel9.Visible = false;
                button1Clicked = false;
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (!button2Clicked)
            {
                button2Clicked = true;

            }
            else
            {
                button2Clicked = false;
            }

        }

        private void FileMenuButton1_MouseEnter(object sender, EventArgs e)
        {
            panel2.BackColor = Color.FromArgb(83, 83, 83);
        }

        private void FileMenuButton1_MouseLeave(object sender, EventArgs e)
        {
            panel2.BackColor = Color.FromArgb(40, 40, 40);
        }

        private void FileMenuButton2_MouseEnter(object sender, EventArgs e)
        {
            panel3.BackColor = Color.FromArgb(83, 83, 83);
        }

        private void FileMenuButton2_MouseLeave(object sender, EventArgs e)
        {
            panel3.BackColor = Color.FromArgb(40, 40, 40);
        }
        private void FileMenuButton3_MouseEnter(object sender, EventArgs e)
        {
            panel4.BackColor = Color.FromArgb(83, 83, 83);
        }

        private void FileMenuButton3_MouseLeave(object sender, EventArgs e)
        {
            panel4.BackColor = Color.FromArgb(40, 40, 40);
        }
        private void FileMenuButton4_MouseEnter(object sender, EventArgs e)
        {
            panel5.BackColor = Color.FromArgb(83, 83, 83);
        }

        private void FileMenuButton4_MouseLeave(object sender, EventArgs e)
        {
            panel5.BackColor = Color.FromArgb(40, 40, 40);
        }
        private void FileMenuButton1_Click(object sender, EventArgs e)
        {
            // Create and configure OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            // Show the dialog and check if the user selected a file
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Load the selected image into pictureBox2
                Image selectedImage = Image.FromFile(openFileDialog.FileName);

                // Calculate scaling factors
                float widthScale = (int)customPanel7.Width / selectedImage.Width;
                float heightScale = (int)customPanel7.Height / selectedImage.Height;
                float scaleFactor = Math.Min(widthScale, heightScale);

                if (selectedImage.Width > customPanel7.Width || selectedImage.Height > customPanel7.Height)
                {
                    // Calculate the new size based on the scale factor
                    int newWidth = (int)(selectedImage.Width / 2);
                    int newHeight = (int)(selectedImage.Height / 2);
                    scrollBarV1.TurnedOn = false;
                    scrollBarH1.TurnedOn = false;
                    //divide if bigger than confine
                    if (newWidth > customPanel7.Width)
                    {
                        int newerWidth = (newWidth / 2);
                        if (newerWidth < newHeight)
                        {
                            newHeight = newerWidth;
                            newWidth = selectedImage.Height / 2;
                        }
                    } else if (newHeight > customPanel7.Height)
                    {
                        int newerHeight = (newHeight / 2);
                        if (newerHeight < newWidth)
                        {
                            newWidth = newerHeight;
                            newHeight = selectedImage.Height / 2;
                        }
                    }

                    // Set PictureBox properties
                    pictureBox2.SizeMode = PictureBoxSizeMode.Normal;
                    pictureBox2.Image = selectedImage;

                    // Set PictureBox size and location
                    pictureBox2.Size = new Size(newWidth, newHeight);

                    // Calculate the new location to center pictureBox2 within customPanel7
                    int x = (customPanel7.Width - pictureBox2.Width) / 2;
                    int y = (customPanel7.Height - pictureBox2.Height) / 2;

                    // Set the new location
                    pictureBox2.Location = new Point(x, y);
                }
                /*if (selectedImage.Width > customPanel7.Width || selectedImage.Height > customPanel7.Height)
                {
                    // Set PictureBox properties
                    pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
                    pictureBox2.Image = selectedImage;

                    // Calculate the new location to center pictureBox2 within customPanel7
                    int x = (customPanel7.Width) / 2 - (pictureBox2.Width) / 2;
                    int y = (customPanel7.Height) / 2 - (pictureBox2.Height) / 2;

                    // Set the new location
                    pictureBox2.Location = new Point(0, 0);
                }*/
                else
                {
                    // Set PictureBoxSizeMode to AutoSize
                    pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
                    pictureBox2.Image = selectedImage;

                    // Calculate the new location to center the pictureBox2 within customPanel7
                    int x = (customPanel7.Width - pictureBox2.Width) / 2;
                    int y = (customPanel7.Height - pictureBox2.Height) / 2;

                    // Set the new location
                    pictureBox2.Location = new Point(x, y);
                    scrollBarV1.TurnedOn = false;
                    scrollBarH1.TurnedOn = false;
                }

                // Update the custom scrollbar's
                int newMaxHeightScroll = Math.Max(selectedImage.Height - customPanel7.ClientSize.Height, 0);
                customPanel7.VerticalScroll.Maximum = newMaxHeightScroll;                
                scrollBarV1.Maximum = newMaxHeightScroll;
                scrollBarV1.LargeChange = (customPanel7.Height * customPanel7.Height) / selectedImage.Height;
                scrollBarV1.Value = 0;
                int newMaxWidthScroll = Math.Max(selectedImage.Width - customPanel7.ClientSize.Width, 0);
                customPanel7.HorizontalScroll.Maximum = newMaxWidthScroll;
                scrollBarH1.Maximum = newMaxWidthScroll;
                scrollBarH1.LargeChange = (customPanel7.Width * customPanel7.Width) / selectedImage.Width;
                scrollBarH1.Value = 0;


                // Debugging outputs
                Console.WriteLine($"Image Size: {selectedImage.Width}x{selectedImage.Height}");
                Console.WriteLine($"Panel Size: {customPanel7.Width}x{customPanel7.Height}");
                Console.WriteLine($"PictureBox Size: {pictureBox2.Width}x{pictureBox2.Height}");
                Console.WriteLine($"PictureBox Location: {pictureBox2.Location}");
                Console.WriteLine($"New Max Height Scroll: {newMaxHeightScroll}");
                Console.WriteLine($"New Max Width Scroll: {newMaxWidthScroll}");
                Console.WriteLine($"Vscroll scrubber: {scrollBarV1.LargeChange}");
                Console.WriteLine($"Hscroll scrubber: {scrollBarH1.LargeChange}");
            }
        }

        private void scrollBarV1_Scroll(object sender, EventArgs e)
        {
            customPanel7.VerticalScroll.Value = scrollBarV1.Value;
            int newValue = scrollBarV1.Value;
            customPanel7.PerformLayout(); // Update the panel layout
            Console.WriteLine($"Scroll Value: {newValue}");
        }

        private void scrollBarH1_Scroll(object sender, EventArgs e)
        {
            customPanel7.HorizontalScroll.Value = scrollBarH1.Value;
            int newValue = scrollBarH1.Value;
            customPanel7.PerformLayout(); // Update the panel layout
            Console.WriteLine($"Scroll Value: {newValue}");
        }
    }
}
