﻿
namespace ScreenshotMagician.CustomControls
{
    partial class ScrollBarH
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.track = new System.Windows.Forms.Panel();
            this.thumb = new System.Windows.Forms.Panel();
            this.leftArrow = new System.Windows.Forms.Panel();
            this.rightArrow = new System.Windows.Forms.Panel();
            this.track.SuspendLayout();
            this.SuspendLayout();
            // 
            // track
            // 
            this.track.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.track.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.track.Controls.Add(this.thumb);
            this.track.Location = new System.Drawing.Point(15, 0);
            this.track.Name = "track";
            this.track.Size = new System.Drawing.Size(50, 17);
            this.track.TabIndex = 0;
            // 
            // thumb
            // 
            this.thumb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.thumb.Location = new System.Drawing.Point(0, 1);
            this.thumb.Name = "thumb";
            this.thumb.Size = new System.Drawing.Size(15, 15);
            this.thumb.TabIndex = 3;
            // 
            // leftArrow
            // 
            this.leftArrow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.leftArrow.BackgroundImage = global::ScreenshotMagician.Properties.Resources.LeftArrow;
            this.leftArrow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.leftArrow.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftArrow.Location = new System.Drawing.Point(0, 0);
            this.leftArrow.Name = "leftArrow";
            this.leftArrow.Size = new System.Drawing.Size(17, 17);
            this.leftArrow.TabIndex = 2;
            // 
            // rightArrow
            // 
            this.rightArrow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.rightArrow.BackgroundImage = global::ScreenshotMagician.Properties.Resources.RightArrow;
            this.rightArrow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.rightArrow.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightArrow.Location = new System.Drawing.Point(63, 0);
            this.rightArrow.Name = "rightArrow";
            this.rightArrow.Size = new System.Drawing.Size(17, 17);
            this.rightArrow.TabIndex = 1;
            // 
            // ScrollBarH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.leftArrow);
            this.Controls.Add(this.rightArrow);
            this.Controls.Add(this.track);
            this.Name = "ScrollBarH";
            this.Size = new System.Drawing.Size(80, 17);
            this.track.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel track;
        private System.Windows.Forms.Panel rightArrow;
        private System.Windows.Forms.Panel leftArrow;
        private System.Windows.Forms.Panel thumb;
    }
}
