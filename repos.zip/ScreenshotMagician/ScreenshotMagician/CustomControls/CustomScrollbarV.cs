﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ScreenshotMagician.CustomControls
{
    public partial class CustomScrollBarV : UserControl
    {
        private bool isDragging = false;
        private Point offset;
        private int scrollValue = 0;
        private const int scrollStep = 10; // Amount to scroll per arrow click
        private int maximum = 100;
        private int scrubberSize = 100;
        private bool scrollEnabled = false;
       // private int visibleHeight;
       // private int contentHeight;

        // Declare the stopScrolling field
        private MouseEventHandler stopScrolling;

        // Event to notify when the scroll value changes
        public event EventHandler ScrollValueChanged;

        public CustomScrollBarV()
        {
            InitializeComponent();
            //UpdateScrollBarPosition();
            offset = Point.Empty;
        }



        /*public void SetSizes(int visibleHeight, int contentHeight)
        {
            this.visibleHeight = visibleHeight;
            this.contentHeight = contentHeight;
            Console.WriteLine($"Visible height: {visibleHeight}");
            Console.WriteLine($"Content height: {contentHeight}");

            // Calculate the scrubber height
            double visibleRatio = (double)visibleHeight / contentHeight;
            int scrubberHeight = (int)(visibleRatio * visibleHeight);
            scrubberHeight = Math.Max(scrubberHeight, 20); // Minimum scrubber height
            ScrubberSize = scrubberHeight;

            // Update scrollbar maximum
            int maxScroll = contentHeight - visibleHeight;
            if (scrollValue > maxScroll) scrollValue = maxScroll;
            //UpdateScrollBarPosition();

        }*/

        /*public void UpdateScrollBarPosition()
        {
            if (contentHeight <= visibleHeight) // If content fits within the visible area
            {
                customPanel6.Top = 0; // No need to scroll
                scrollValue = 0; // Reset scrollValue
            }
            else
            {
                int maxScroll = Maximum;
                if (scrollValue < 0) scrollValue = 0;
                if (scrollValue > maxScroll) scrollValue = maxScroll;
                customPanel6.Top = scrollValue;
                Console.WriteLine($"Max Scroll: {maxScroll}");
            }
            // Raise the ScrollValueChanged event
            ScrollValueChanged?.Invoke(this, EventArgs.Empty);
        }*/

        public int ScrollValue
        {
            get { return scrollValue; }
            set
            {
                scrollValue = value;
                //UpdateScrollBarPosition();
            }
        }

        public bool ScrollEnabled
        {
            get { return scrollEnabled; }
            set
            {
                scrollEnabled = value;
                this.Visible = scrollEnabled; // Set visibility based on ScrollEnabled
                //UpdateScrollBarPosition();
            }
        }

        public int Maximum
        {
            get { return maximum; }
            set
            {
                if (maximum != value)
                {
                    maximum = value;
                    // Ensure the current scroll value is within the new maximum
                    if (scrollValue > maximum)
                    {
                        scrollValue = maximum;
                        //UpdateScrollBarPosition();
                    }
                }
            }
        }

        public int ScrubberSize
        {
            get { return scrubberSize; }
            set
            {
                scrubberSize = value;
                customPanel6.Height = scrubberSize;
                //UpdateScrollBarPosition();
            }
        }

        private void customPanel3_MouseDown(object sender, MouseEventArgs e)
        {
            StartScrolling(ScrollDown);
            customPanel3.BackColor = Color.Black;
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            StartScrolling(ScrollDown);
            customPanel3.BackColor = Color.Black;
        }

        private void customPanel4_MouseDown(object sender, MouseEventArgs e)
        {
            StartScrolling(ScrollUp);
            customPanel4.BackColor = Color.Black;
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            StartScrolling(ScrollUp);
            customPanel4.BackColor = Color.Black;
        }

        private void StartScrolling(Action scrollAction)
        {
            Timer scrollTimer = new Timer();
            scrollTimer.Interval = 100; // Time interval in milliseconds
            scrollTimer.Tick += (s, ea) => scrollAction();
            scrollTimer.Start();

            // Initialize stopScrolling handler
            stopScrolling = (s, ea) =>
            {
                scrollTimer.Stop();
                // Unsubscribe all MouseUp handlers
                customPanel3.MouseUp -= stopScrolling;
                label1.MouseUp -= stopScrolling;
                customPanel4.MouseUp -= stopScrolling;
                label2.MouseUp -= stopScrolling;
                customPanel3.BackColor = Color.FromArgb(73, 73, 73);
                customPanel4.BackColor = Color.FromArgb(73, 73, 73);
            };

            // Attach stopScrolling handler
            customPanel3.MouseUp += stopScrolling;
            label1.MouseUp += stopScrolling;
            customPanel4.MouseUp += stopScrolling;
            label2.MouseUp += stopScrolling;
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                offset = e.Location;
            }
        }

        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point newLocation = customPanel6.Location;
                newLocation.Y += e.Y - offset.Y;

                // Ensure newLocation is within the bounds of customPanel5 on the Y axis
                newLocation.Y = Math.Max(customPanel5.Top - 16, Math.Min(newLocation.Y, (customPanel5.Bottom - 16) - customPanel6.Height));

                customPanel6.Location = newLocation;
                scrollValue = newLocation.Y;
                // Raise the ScrollValueChanged event
                ScrollValueChanged?.Invoke(this, EventArgs.Empty);
            }
        }

        private void MainForm_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void ScrollDown()
        {
            int maxScroll = Maximum;
            if (scrollValue < maxScroll)
            {
                scrollValue += scrollStep;
                //UpdateScrollBarPosition();
            }
        }

        private void ScrollUp()
        {
            if (scrollValue > 0)
            {
                scrollValue -= scrollStep;
                //UpdateScrollBarPosition();
            }
        }
    }
}
