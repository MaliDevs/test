﻿
namespace ScreenshotMagician.CustomControls
{
    partial class ScrollBarV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.track = new System.Windows.Forms.Panel();
            this.thumb = new System.Windows.Forms.Panel();
            this.upArrow = new System.Windows.Forms.Panel();
            this.downArrow = new System.Windows.Forms.Panel();
            this.track.SuspendLayout();
            this.SuspendLayout();
            // 
            // track
            // 
            this.track.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.track.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.track.Controls.Add(this.thumb);
            this.track.Location = new System.Drawing.Point(0, 15);
            this.track.Name = "track";
            this.track.Size = new System.Drawing.Size(17, 50);
            this.track.TabIndex = 0;
            // 
            // thumb
            // 
            this.thumb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.thumb.Location = new System.Drawing.Point(1, 0);
            this.thumb.Name = "thumb";
            this.thumb.Size = new System.Drawing.Size(15, 15);
            this.thumb.TabIndex = 3;
            // 
            // upArrow
            // 
            this.upArrow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.upArrow.BackgroundImage = global::ScreenshotMagician.Properties.Resources.UpArrow;
            this.upArrow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.upArrow.Dock = System.Windows.Forms.DockStyle.Top;
            this.upArrow.Location = new System.Drawing.Point(0, 0);
            this.upArrow.Name = "upArrow";
            this.upArrow.Size = new System.Drawing.Size(17, 15);
            this.upArrow.TabIndex = 2;
            // 
            // downArrow
            // 
            this.downArrow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.downArrow.BackgroundImage = global::ScreenshotMagician.Properties.Resources.DownArrow;
            this.downArrow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.downArrow.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.downArrow.Location = new System.Drawing.Point(0, 65);
            this.downArrow.Name = "downArrow";
            this.downArrow.Size = new System.Drawing.Size(17, 15);
            this.downArrow.TabIndex = 1;
            // 
            // ScrollBarV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.upArrow);
            this.Controls.Add(this.downArrow);
            this.Controls.Add(this.track);
            this.Name = "ScrollBarV";
            this.Size = new System.Drawing.Size(17, 80);
            this.track.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel track;
        private System.Windows.Forms.Panel downArrow;
        private System.Windows.Forms.Panel upArrow;
        private System.Windows.Forms.Panel thumb;
    }
}
