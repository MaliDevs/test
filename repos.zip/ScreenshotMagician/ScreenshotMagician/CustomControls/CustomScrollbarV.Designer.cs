﻿
namespace ScreenshotMagician.CustomControls
{
    partial class CustomScrollBarV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customPanel1 = new ScreenshotMagician.CustomControls.CustomPanel();
            this.customPanel5 = new ScreenshotMagician.CustomControls.CustomPanel();
            this.customPanel6 = new ScreenshotMagician.CustomControls.CustomPanel();
            this.customPanel4 = new ScreenshotMagician.CustomControls.CustomPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.customPanel3 = new ScreenshotMagician.CustomControls.CustomPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.customPanel1.SuspendLayout();
            this.customPanel5.SuspendLayout();
            this.customPanel4.SuspendLayout();
            this.customPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // customPanel1
            // 
            this.customPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.customPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.customPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel1.Controls.Add(this.customPanel5);
            this.customPanel1.Controls.Add(this.customPanel4);
            this.customPanel1.Controls.Add(this.customPanel3);
            this.customPanel1.Location = new System.Drawing.Point(0, 0);
            this.customPanel1.MaximumSize = new System.Drawing.Size(1014, 600);
            this.customPanel1.Name = "customPanel1";
            this.customPanel1.Size = new System.Drawing.Size(16, 258);
            this.customPanel1.TabIndex = 0;
            // 
            // customPanel5
            // 
            this.customPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel5.Controls.Add(this.customPanel6);
            this.customPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customPanel5.Location = new System.Drawing.Point(0, 16);
            this.customPanel5.MaximumSize = new System.Drawing.Size(1014, 600);
            this.customPanel5.Name = "customPanel5";
            this.customPanel5.Size = new System.Drawing.Size(16, 226);
            this.customPanel5.TabIndex = 3;
            // 
            // customPanel6
            // 
            this.customPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.customPanel6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.customPanel6.Location = new System.Drawing.Point(2, 77);
            this.customPanel6.MaximumSize = new System.Drawing.Size(1014, 600);
            this.customPanel6.Name = "customPanel6";
            this.customPanel6.Size = new System.Drawing.Size(12, 59);
            this.customPanel6.TabIndex = 1;
            this.customPanel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.customPanel6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.customPanel6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
            // 
            // customPanel4
            // 
            this.customPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel4.Controls.Add(this.label2);
            this.customPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.customPanel4.Location = new System.Drawing.Point(0, 0);
            this.customPanel4.MaximumSize = new System.Drawing.Size(1014, 600);
            this.customPanel4.Name = "customPanel4";
            this.customPanel4.Size = new System.Drawing.Size(16, 16);
            this.customPanel4.TabIndex = 2;
            this.customPanel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customPanel4_MouseDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "▲";
            this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label2_MouseDown);
            // 
            // customPanel3
            // 
            this.customPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.customPanel3.Controls.Add(this.label1);
            this.customPanel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.customPanel3.Location = new System.Drawing.Point(0, 242);
            this.customPanel3.MaximumSize = new System.Drawing.Size(1014, 600);
            this.customPanel3.Name = "customPanel3";
            this.customPanel3.Size = new System.Drawing.Size(16, 16);
            this.customPanel3.TabIndex = 1;
            this.customPanel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customPanel3_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.label1.Location = new System.Drawing.Point(0, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "▼";
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(16, 258);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // CustomScrollBarV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Lime;
            this.Controls.Add(this.customPanel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "CustomScrollBarV";
            this.Size = new System.Drawing.Size(16, 258);
            this.customPanel1.ResumeLayout(false);
            this.customPanel5.ResumeLayout(false);
            this.customPanel4.ResumeLayout(false);
            this.customPanel4.PerformLayout();
            this.customPanel3.ResumeLayout(false);
            this.customPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private CustomPanel customPanel1;
        private CustomPanel customPanel5;
        private CustomPanel customPanel6;
        private CustomPanel customPanel4;
        private System.Windows.Forms.Label label2;
        private CustomPanel customPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    }
}
