﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ScreenshotMagician.CustomControls
{
    public partial class ScrollBarV : UserControl
    {
        private bool isDragging = false;
        private bool isScrollingUp = false;
        private bool isScrollingDown = false;
        private int minimum = 0;
        private int maximum = 100;
        private int value = 0;
        private int largeChange = 10;
        private int smallChange = 1;
        private bool turnedOn = true;

        private int mouseOffsetY; // To store the mouse offset during dragging
        private Timer scrollTimer; // Timer for continuous scrolling

        public ScrollBarV()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.Load += ScrollBarV_Load;
            this.Resize += ScrollBarV_Resize;
            this.track.Paint += Track_Paint;
            this.track.MouseDown += Track_MouseDown;
            this.thumb.MouseDown += Thumb_MouseDown;
            this.thumb.MouseMove += Thumb_MouseMove;
            this.thumb.MouseUp += Thumb_MouseUp;
            this.upArrow.MouseDown += UpArrow_MouseDown;
            this.upArrow.MouseUp += Arrow_MouseUp;
            this.downArrow.MouseDown += DownArrow_MouseDown;
            this.downArrow.MouseUp += Arrow_MouseUp;

            // Initialize and configure the timer
            scrollTimer = new Timer();
            scrollTimer.Interval = 10; // Time interval for repeating action (ms)
            scrollTimer.Tick += ScrollTimer_Tick;
        }

        private void ScrollBarV_Load(object sender, EventArgs e)
        {
            // Initialize thumb position on load
            UpdateThumbPosition();
        }

        private void ScrollBarV_Resize(object sender, EventArgs e)
        {
            // Recalculate thumb position when resized
            UpdateThumbPosition();
        }

        public event EventHandler Scroll;

        public int Minimum
        {
            get { return minimum; }
            set
            {
                if (value < maximum)
                {
                    minimum = value;
                    if (this.value < minimum)
                    {
                        this.value = minimum;
                        OnScroll(EventArgs.Empty);
                    }
                    UpdateThumbPosition();
                }
            }
        }

        public int Maximum
        {
            get { return maximum; }
            set
            {
                if (value > minimum)
                {
                    maximum = value;
                    if (this.value > maximum)
                    {
                        this.value = maximum;
                        OnScroll(EventArgs.Empty);
                    }
                    UpdateThumbPosition();
                }
            }
        }

        public int Value
        {
            get { return this.value; }
            set
            {
                if (value >= minimum && value <= maximum)
                {
                    this.value = value;
                    UpdateThumbPosition();
                    OnScroll(EventArgs.Empty);
                }
            }
        }

        public int LargeChange
        {
            get { return largeChange; }
            set
            {
                if (value > 0)
                {
                    largeChange = value;
                }
            }
        }

        public int SmallChange
        {
            get { return smallChange; }
            set
            {
                if (value > 0)
                {
                    smallChange = value;
                }
            }
        }

        public bool TurnedOn
        {
            get { return turnedOn; }
            set
            {
                if (turnedOn != value)
                {
                    turnedOn = value;
                    this.track.Visible = turnedOn;
                    this.upArrow.Visible = turnedOn;
                    this.downArrow.Visible = turnedOn;
                }
            }
        }

        private void Track_Paint(object sender, PaintEventArgs e)
        {
            // Optional: Draw track background or borders
        }

        private void Track_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int newTop = Math.Max(0, Math.Min(track.Height - thumb.Height, e.Y - thumb.Height / 2));
                thumb.Top = newTop;
                UpdateValueFromThumb();
                OnScroll(EventArgs.Empty);
            }
        }
        private void Thumb_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                // Calculate the offset between the mouse position and the thumb's top
                mouseOffsetY = e.Y;
            }
        }

        private void Thumb_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                // Calculate the new thumb position with respect to the mouse movement
                int newTop = Math.Max(0, Math.Min(track.Height - thumb.Height, e.Y - mouseOffsetY + thumb.Top));
                thumb.Top = newTop;
                UpdateValueFromThumb();
                OnScroll(EventArgs.Empty);
            }
        }

        private void Thumb_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }

        private void UpArrow_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingUp = true;
                ScrollUp();
                scrollTimer.Start(); // Start timer for continuous scrolling
            }
        }

        private void DownArrow_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingDown = true;
                ScrollDown();
                scrollTimer.Start(); // Start timer for continuous scrolling
            }
        }

        private void Arrow_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingUp = false;
                isScrollingDown = false;
                scrollTimer.Stop(); // Stop timer when button is released
            }
        }

        private void ScrollTimer_Tick(object sender, EventArgs e)
        {
            if (isScrollingUp)
            {
                ScrollUp();
            }

            if (isScrollingDown)
            {
                ScrollDown();
            }
        }

        private void ScrollUp()
        {
            Value = Math.Max(minimum, value - smallChange);
        }

        private void ScrollDown()
        {
            Value = Math.Min(maximum, value + smallChange);
        }

        private void UpdateThumbPosition()
        {
            if (track.Height == 0 || maximum == minimum) return;

            // Calculate thumb size and position
            double trackHeight = track.Height;
            double thumbHeight = Math.Max(15, (largeChange / (double)(maximum - minimum)) * trackHeight);
            thumb.Size = new Size(thumb.Width, (int)thumbHeight);

            double percentage = (double)(value - minimum) / (maximum - minimum);
            thumb.Top = (int)(percentage * (trackHeight - thumb.Height));
        }

        private void UpdateValueFromThumb()
        {
            if (track.Height == 0 || maximum == minimum) return;

            double trackHeight = track.Height;
            double thumbHeight = thumb.Height;

            double percentage = (double)(thumb.Top) / (trackHeight - thumbHeight);
            Value = (int)(percentage * (maximum - minimum)) + minimum;
        }

        protected virtual void OnScroll(EventArgs e)
        {
            Scroll?.Invoke(this, e);
        }
    }
}
