﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;

namespace ScreenshotMagician.CustomControls
{
    public class CustomPanel : Panel
    {
        private Color borderColor = Color.FromArgb(73, 73, 73);

        public Color BorderColor { get => this.borderColor; set => this.borderColor = value; }

        public CustomPanel()
        {
            //this.MaximumSize = new Size(1014, 600);
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            ControlPaint.DrawBorder(pevent.Graphics, this.ClientRectangle, borderColor, ButtonBorderStyle.Solid);
        }

        protected override void OnLayout(LayoutEventArgs levent)
        {
            base.OnLayout(levent);
            // Ensure scrollbars are hidden
            this.VerticalScroll.Visible = false;
            this.HorizontalScroll.Visible = false;
        }

        protected override void WndProc(ref Message m)
        {
            // Suppress scrollbar painting but retain other functionality
            const int WM_NCCALCSIZE = 0x0083;
            const int WM_NCPAINT = 0x0085;

            if (m.Msg == WM_NCCALCSIZE || m.Msg == WM_NCPAINT)
            {
                // Suppress the scrollbars' non-client area calculations and painting
                return;
            }

            base.WndProc(ref m);
        }

        public void UpdateScrollbars()
        {
            // Force panel to update its scrollbars if needed
            this.VerticalScroll.Visible = false;
            this.HorizontalScroll.Visible = false;
            this.PerformLayout();
        }
    }
}



