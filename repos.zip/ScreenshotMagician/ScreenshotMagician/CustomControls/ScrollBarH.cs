﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ScreenshotMagician.CustomControls
{
    public partial class ScrollBarH : UserControl
    {
        private bool isDragging = false;
        private bool isScrollingUp = false;
        private bool isScrollingDown = false;
        private int minimum = 0;
        private int maximum = 100;
        private int value = 0;
        private int largeChange = 10;
        private int smallChange = 1;
        private bool turnedOn = true;

        private int mouseOffsetX; // To store the mouse offset during dragging
        private Timer scrollTimer; // Timer for continuous scrolling

        public ScrollBarH()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.Load += ScrollBarH_Load;
            this.Resize += ScrollBarH_Resize;
            this.track.Paint += Track_Paint;
            this.track.MouseDown += Track_MouseDown;
            this.thumb.MouseDown += Thumb_MouseDown;
            this.thumb.MouseMove += Thumb_MouseMove;
            this.thumb.MouseUp += Thumb_MouseUp;
            this.leftArrow.MouseDown += LeftArrow_MouseDown;
            this.leftArrow.MouseUp += Arrow_MouseUp;
            this.rightArrow.MouseDown += RightArrow_MouseDown;
            this.rightArrow.MouseUp += Arrow_MouseUp;

            // Initialize and configure the timer
            scrollTimer = new Timer();
            scrollTimer.Interval = 10; // Time interval for repeating action (ms)
            scrollTimer.Tick += ScrollTimer_Tick;
        }

        private void ScrollBarH_Load(object sender, EventArgs e)
        {
            // Initialize thumb position on load
            UpdateThumbPosition();
        }

        private void ScrollBarH_Resize(object sender, EventArgs e)
        {
            // Recalculate thumb position when resized
            UpdateThumbPosition();
        }

        public event EventHandler Scroll;

        public int Minimum
        {
            get { return minimum; }
            set
            {
                if (value < maximum)
                {
                    minimum = value;
                    if (this.value < minimum)
                    {
                        this.value = minimum;
                        OnScroll(EventArgs.Empty);
                    }
                    UpdateThumbPosition();
                }
            }
        }

        public int Maximum
        {
            get { return maximum; }
            set
            {
                if (value > minimum)
                {
                    maximum = value;
                    if (this.value > maximum)
                    {
                        this.value = maximum;
                        OnScroll(EventArgs.Empty);
                    }
                    UpdateThumbPosition();
                }
            }
        }

        public int Value
        {
            get { return this.value; }
            set
            {
                if (value >= minimum && value <= maximum)
                {
                    this.value = value;
                    UpdateThumbPosition();
                    OnScroll(EventArgs.Empty);
                }
            }
        }

        public int LargeChange
        {
            get { return largeChange; }
            set
            {
                if (value > 0)
                {
                    largeChange = value;
                }
            }
        }

        public int SmallChange
        {
            get { return smallChange; }
            set
            {
                if (value > 0)
                {
                    smallChange = value;
                }
            }
        }

        public bool TurnedOn
        {
            get { return turnedOn; }
            set
            {
                if (turnedOn != value)
                {
                    turnedOn = value;
                    this.track.Visible = turnedOn;
                    this.leftArrow.Visible = turnedOn;
                    this.rightArrow.Visible = turnedOn;
                }
            }
        }

        private void Track_Paint(object sender, PaintEventArgs e)
        {
            // Optional: Draw track background or borders
        }

        private void Track_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int newLeft = Math.Max(0, Math.Min(track.Width - thumb.Width, e.X - thumb.Width / 2));
                thumb.Left = newLeft;
                UpdateValueFromThumb();
                OnScroll(EventArgs.Empty);
            }
        }

        private void Thumb_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                // Calculate the offset between the mouse position and the thumb's left
                mouseOffsetX = e.X;
            }
        }

        private void Thumb_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                // Calculate the new thumb position with respect to the mouse movement
                int newLeft = Math.Max(0, Math.Min(track.Width - thumb.Width, e.X - mouseOffsetX + thumb.Left));
                thumb.Left = newLeft;
                UpdateValueFromThumb();
                OnScroll(EventArgs.Empty);
            }
        }

        private void Thumb_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }

        private void LeftArrow_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingUp = true;
                ScrollUp();
                scrollTimer.Start(); // Start timer for continuous scrolling
            }
        }

        private void RightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingDown = true;
                ScrollDown();
                scrollTimer.Start(); // Start timer for continuous scrolling
            }
        }

        private void Arrow_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isScrollingUp = false;
                isScrollingDown = false;
                scrollTimer.Stop(); // Stop timer when button is released
            }
        }

        private void ScrollTimer_Tick(object sender, EventArgs e)
        {
            if (isScrollingUp)
            {
                ScrollUp();
            }

            if (isScrollingDown)
            {
                ScrollDown();
            }
        }

        private void ScrollUp()
        {
            Value = Math.Max(minimum, value - smallChange);
        }

        private void ScrollDown()
        {
            Value = Math.Min(maximum, value + smallChange);
        }

        private void UpdateThumbPosition()
        {
            if (track.Width == 0 || maximum == minimum) return;

            // Calculate thumb size and position
            double trackWidth = track.Width;
            double thumbWidth = Math.Max(15, (largeChange / (double)(maximum - minimum)) * trackWidth);
            thumb.Width = (int)thumbWidth;

            double percentage = (double)(value - minimum) / (maximum - minimum);
            thumb.Left = (int)(percentage * (trackWidth - thumb.Width));
        }

        private void UpdateValueFromThumb()
        {
            if (track.Width == 0 || maximum == minimum) return;

            double trackWidth = track.Width;
            double thumbWidth = thumb.Width;

            double percentage = (double)(thumb.Left) / (trackWidth - thumbWidth);
            Value = (int)(percentage * (maximum - minimum)) + minimum;
        }

        protected virtual void OnScroll(EventArgs e)
        {
            Scroll?.Invoke(this, e);
        }
    }
}
